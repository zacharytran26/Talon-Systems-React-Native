import React, { useRef } from "react";
import { View, StyleSheet, Animated } from "react-native";
import { useRoute } from "@react-navigation/native";
import { PinchGestureHandler, State } from "react-native-gesture-handler";

const DisplayImage = () => {
  const route = useRoute();
  const { imageUri } = route.params;

  const scale = useRef(new Animated.Value(1)).current;

  const onPinchEvent = Animated.event([{ nativeEvent: { scale: scale } }], {
    useNativeDriver: true,
  });

  const onPinchStateChange = (event) => {
    if (event.nativeEvent.state === State.END) {
      Animated.spring(scale, {
        toValue: 1,
        useNativeDriver: true,
        bounciness: 1,
      }).start();
    }
  };

  return (
    <View style={styles.container}>
      <PinchGestureHandler
        onGestureEvent={onPinchEvent}
        onHandlerStateChange={onPinchStateChange}
      >
        <Animated.Image
          style={[styles.image, { transform: [{ scale: scale }] }]}
          source={{ uri: imageUri }}
        />
      </PinchGestureHandler>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F7F9FC",
  },
  image: {
    width: "75%",
    height: "75%",
    resizeMode: "contain",
  },
});

export default DisplayImage;
