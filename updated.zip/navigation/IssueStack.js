import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import MyIssues from "../screens/MyIssues";

import InstructorsScreen from "../screens/IssueScreens/InstructorScreen";
import StudentsScreen from "../screens/IssueScreens/StudentScreen";
import InstructorList from "../screens/IssueScreens/InstructorDetailScreen";
import StudentList from "../screens/IssueScreens/StudentDetailScreen";
import LogoutScreen from "../screens/IssueScreens/Logout";
import StudentCourse from "../screens/IssueScreens/StudentCourseScreen";
import StudentMap from "../screens/IssueScreens/StudentMap";
import StudentMapDetails from "../screens/IssueScreens/StudentMapsDetail";
import LineItem from "../screens/IssueScreens/LineItems";
import Approve from "../screens/IssueScreens/ApprovalScreen";
import Times from "../screens/IssueScreens/TimesScreen";
import DisplayImage from "../screens/IssueScreens/ImageScreen";
import InstructorActivity from "../screens/IssueScreens/InstructorActivity";
import ConfirmFIF from "../screens/IssueScreens/ConfirmationFIF";
import SettingsScreen from "../screens/IssueScreens/SettingScreen";
import PendingAuths from "../screens/IssueScreens/PendingAuths";
import FIFScreen from "../screens/IssueScreens/FIFScreen";
import LogScreen from "../screens/IssueScreens/LogScreen";

const Stack = createNativeStackNavigator();

export default function IssueStackNavigator() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerBackTitleVisible: false,
        headerStyle: {
          backgroundColor: "#f7f9fc",
        },
        headerTitle: "",
      }}
    >
      <Stack.Screen name="Issues" component={MyIssues} />
      <Stack.Screen
        name="IssueInstructorScreen"
        component={InstructorsScreen}
      />
      <Stack.Screen name="IssueStudentScreen" component={StudentsScreen} />
      <Stack.Screen
        name="IssueInstructorDetailScreen"
        component={InstructorList}
      />
      <Stack.Screen name="IssueStudentDetailScreen" component={StudentList} />
      <Stack.Screen name="IssueLogout" component={LogoutScreen} />
      <Stack.Screen name="IssueStudentCourse" component={StudentCourse} />
      <Stack.Screen name="IssueStudentMap" component={StudentMap} />
      <Stack.Screen
        name="IssueStudentMapDetails"
        component={StudentMapDetails}
      />
      <Stack.Screen name="IssueLineItem" component={LineItem} />
      <Stack.Screen name="IssueAuth" component={Approve} />
      <Stack.Screen name="IssueTimes" component={Times} />
      <Stack.Screen name="IssueImage" component={DisplayImage} />
      <Stack.Screen
        name="IssueInstructorActivity"
        component={InstructorActivity}
      />
      <Stack.Screen name="IssueConfirm" component={ConfirmFIF} />
      <Stack.Screen name="IssueLog" component={LogScreen} />
      <Stack.Screen name="IssueSettings" component={SettingsScreen} />
      <Stack.Screen name="IssuePendingAuth" component={PendingAuths} />
      <Stack.Screen name="IssueFIF" component={FIFScreen} />
    </Stack.Navigator>
  );
}
