import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { View, Text, StyleSheet } from "react-native";
import {
  BottomNavigation,
  BottomNavigationTab,
  Icon,
} from "@ui-kitten/components";
import HomeDrawerNavigator from "./HomeDrawer";
import IssueDrawerNavigator from "./IssueDrawer";
import CurrencyDrawerNavigator from "./CurrencyDrawer";
import MessagesDrawerNavigator from "./MessagesDrawer";
import QualiDrawerNavigator from "./QualiDrawer"; // Assuming this exists
import { useAuth } from "../screens/ThemeContext"; // Assuming useAuth gives access to tabBarBadge

const { Navigator, Screen } = createBottomTabNavigator();

const BottomTabBar = ({ navigation, state }) => {
  const { tabBarBadge } = useAuth(); // Fetch tabBarBadge from context

  // Function to dynamically determine icon color
  const getIconColor = (route, focused) => {
    let iconColor;

    if (route.name === "mHome") {
      iconColor = focused ? "blue" : "gray";
    } else if (route.name === "mIssue") {
      iconColor = focused ? "red" : "gray"; // Red when active
    } else if (route.name === "mQualifications") {
      iconColor = focused ? "blue" : "gray"; // Yellow when active
    } else if (route.name === "mCurrency") {
      // Handle special badge condition for the currency tab only
      if (tabBarBadge > 0) {
        iconColor = "red"; // Red if there are expired currencies
      } else {
        iconColor = focused ? "yellow" : "gray"; // Green when active
      }
    } else if (route.name === "mMessages") {
      iconColor = focused ? "blue" : "gray"; // Orange when active
    }

    return iconColor;
  };

  // Custom function to render a badge only for the currency tab
  const renderIconWithBadge = (iconName, routeName, index) => (props) => {
    const isFocused = state.index === index;
    const iconColor = getIconColor({ name: routeName }, isFocused);

    return (
      <View style={styles.iconContainer}>
        <Icon {...props} name={iconName} fill={iconColor} />
        {routeName === "mCurrency" && tabBarBadge > 0 && (
          <View style={styles.badgeContainer}>
            <Text style={styles.badgeText}>{tabBarBadge}</Text>
          </View>
        )}
      </View>
    );
  };

  // Handle tab selection logic
  const handleSelect = (index) => {
    const selectedTab = state.routeNames[index];
    const isCurrentTab = state.index === index;

    if (isCurrentTab) {
      navigation.reset({
        index: 0,
        routes: [{ name: selectedTab }],
      });
    } else {
      navigation.navigate(selectedTab);
    }
  };

  // Render each tab with the appropriate icon and color (badge only for mCurrency)
  return (
    <BottomNavigation selectedIndex={state.index} onSelect={handleSelect}>
      <BottomNavigationTab
        icon={renderIconWithBadge("home-outline", "mHome", 0)}
      />
      <BottomNavigationTab
        icon={renderIconWithBadge("alert-triangle-outline", "mIssue", 1)}
      />
      <BottomNavigationTab
        icon={renderIconWithBadge("file-text-outline", "mQualifications", 2)}
      />
      <BottomNavigationTab
        icon={renderIconWithBadge("checkmark-circle-2-outline", "mCurrency", 3)} // Badge only for Currency
      />
      <BottomNavigationTab
        icon={renderIconWithBadge("message-circle-outline", "mMessages", 4)}
      />
    </BottomNavigation>
  );
};

export default function MainBottomNav() {
  const { tabBarBadge } = useAuth(); // Fetch tabBarBadge from context

  return (
    <Navigator
      tabBar={(props) => <BottomTabBar {...props} />} // Pass props to custom BottomTabBar
      screenOptions={{ headerShown: false }} // Hide header for all screens
    >
      <Screen name="mHome" component={HomeDrawerNavigator} />
      <Screen name="mIssue" component={IssueDrawerNavigator} />
      <Screen name="mQualifications" component={QualiDrawerNavigator} />
      <Screen
        name="mCurrency"
        component={CurrencyDrawerNavigator}
        options={{
          tabBarBadge: tabBarBadge > 0 ? tabBarBadge : null, // Badge logic for screen
          tabBarBadgeStyle: { backgroundColor: "red" },
        }}
      />
      <Screen name="mMessages" component={MessagesDrawerNavigator} />
    </Navigator>
  );
}
const styles = StyleSheet.create({
  iconContainer: {
    position: "relative",
    width: 24, // Adjust based on your icon size
    height: 24,
  },
  badgeContainer: {
    position: "absolute",
    top: -4,
    right: -4,
    backgroundColor: "red",
    borderRadius: 8,
    paddingHorizontal: 4,
    paddingVertical: 2,
    alignItems: "center",
    justifyContent: "center",
  },
  badgeText: {
    color: "white",
    fontSize: 10,
    fontWeight: "bold",
  },
});
