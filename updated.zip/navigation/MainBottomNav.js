// import React from "react";
// import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
// import {
//   BottomNavigation,
//   BottomNavigationTab,
//   Icon,
// } from "@ui-kitten/components";
// import HomeDrawerNavigator from "./HomeDrawer";
// import IssueDrawerNavigator from "./IssueDrawer";
// import CurrencyDrawerNavigator from "./CurrencyDrawer";
// import MessagesDrawerNavigator from "./MessagesDrawer";
// import QualiDrawerNavigator from "./QualiDrawer"; // Assuming this exists

// const { Navigator, Screen } = createBottomTabNavigator();

// const BottomTabBar = ({ navigation, state }) => {
//   const handleSelect = (index) => {
//     const selectedTab = state.routeNames[index];
//     const isCurrentTab = state.index === index;

//     if (isCurrentTab) {
//       navigation.reset({
//         index: 0,
//         routes: [{ name: selectedTab }],
//       });
//     } else {
//       // Navigate to the selected tab
//       navigation.navigate(selectedTab, {
//         logMessage: `Selected tab: ${selectedTab}`,
//       });
//     }
//   };

//   return (
//     <BottomNavigation selectedIndex={state.index} onSelect={handleSelect}>
//       <BottomNavigationTab
//         icon={(props) => <Icon {...props} name="home-outline" />}
//       />
//       <BottomNavigationTab
//         icon={(props) => <Icon {...props} name="alert-triangle-outline" />}
//       />
//       <BottomNavigationTab
//         icon={(props) => <Icon {...props} name="file-text-outline" />}
//       />
//       <BottomNavigationTab
//         icon={(props) => <Icon {...props} name="checkmark-circle-2-outline" />}
//       />
//       <BottomNavigationTab
//         icon={(props) => <Icon {...props} name="message-circle-outline" />}
//       />
//     </BottomNavigation>
//   );
// };

// export default function MainBottomNav() {
//   return (
//     <Navigator
//       tabBar={(props) => <BottomTabBar {...props} />}
//       screenOptions={{ headerShown: false }}
//     >
//       <Screen name="mHome" component={HomeDrawerNavigator} />
//       <Screen name="mIssue" component={IssueDrawerNavigator} />
//       <Screen name="mQualifications" component={QualiDrawerNavigator} />
//       <Screen name="mCurrency" component={CurrencyDrawerNavigator} />
//       <Screen name="mMessages" component={MessagesDrawerNavigator} />
//     </Navigator>
//   );
// }
import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import {
  BottomNavigation,
  BottomNavigationTab,
  Icon,
} from "@ui-kitten/components";
import HomeDrawerNavigator from "./HomeDrawer";
import IssueDrawerNavigator from "./IssueDrawer";
import CurrencyDrawerNavigator from "./CurrencyDrawer";
import MessagesDrawerNavigator from "./MessagesDrawer";
import QualiDrawerNavigator from "./QualiDrawer"; // Assuming this exists

const { Navigator, Screen } = createBottomTabNavigator();

const BottomTabBar = ({ navigation, state }) => {
  const handleSelect = (index) => {
    const selectedTab = state.routeNames[index];
    const isCurrentTab = state.index === index;

    if (isCurrentTab) {
      navigation.reset({
        index: 0,
        routes: [{ name: selectedTab }],
      });
    } else {
      // Navigate to the selected tab
      navigation.navigate(selectedTab, {
        logMessage: `Selected tab: ${selectedTab}`,
      });
    }
  };

  const renderIcon = (name, index) => (props) => {
    // Set custom icon colors for specific tabs
    let color;

    if (index === 2) {
      // Qualifications tab
      color = "red";
    } else if (index === 3) {
      // Currency tab
      color = "yellow";
    } else {
      // Default color logic for other tabs
      color = state.index === index ? "blue" : "gray";
    }

    return <Icon {...props} name={name} fill={color} />;
  };

  return (
    <BottomNavigation selectedIndex={state.index} onSelect={handleSelect}>
      <BottomNavigationTab icon={renderIcon("home-outline", 0)} />
      <BottomNavigationTab icon={renderIcon("alert-triangle-outline", 1)} />
      <BottomNavigationTab icon={renderIcon("file-text-outline", 2)} />
      <BottomNavigationTab icon={renderIcon("checkmark-circle-2-outline", 3)} />
      <BottomNavigationTab icon={renderIcon("message-circle-outline", 4)} />
    </BottomNavigation>
  );
};

export default function MainBottomNav() {
  return (
    <Navigator
      tabBar={(props) => <BottomTabBar {...props} />}
      screenOptions={{ headerShown: false }}
    >
      <Screen name="mHome" component={HomeDrawerNavigator} />
      <Screen name="mIssue" component={IssueDrawerNavigator} />
      <Screen name="mQualifications" component={QualiDrawerNavigator} />
      <Screen name="mCurrency" component={CurrencyDrawerNavigator} />
      <Screen name="mMessages" component={MessagesDrawerNavigator} />
    </Navigator>
  );
}
