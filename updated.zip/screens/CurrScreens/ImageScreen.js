import React, { useRef } from "react";
import { View, StyleSheet, Animated, Dimensions } from "react-native";
import { useRoute } from "@react-navigation/native";
import {
  PanGestureHandler,
  PinchGestureHandler,
  State,
} from "react-native-gesture-handler";

const { width, height } = Dimensions.get("window");

const DisplayImage = () => {
  const route = useRoute();
  const { imageUri } = route.params;

  // Initialize animated values for scaling and translating (panning)
  const scale = useRef(new Animated.Value(1)).current;
  const translateX = useRef(new Animated.Value(0)).current;
  const translateY = useRef(new Animated.Value(0)).current;
  const lastOffsetX = useRef(0);
  const lastOffsetY = useRef(0);

  // Pan event to move the image
  const onPanEvent = Animated.event(
    [{ nativeEvent: { translationX: translateX, translationY: translateY } }],
    { useNativeDriver: true }
  );

  // Handle end of pan (move) gesture
  const onPanStateChange = (event) => {
    if (event.nativeEvent.state === State.END) {
      lastOffsetX.current += event.nativeEvent.translationX;
      lastOffsetY.current += event.nativeEvent.translationY;
      translateX.setOffset(lastOffsetX.current);
      translateX.setValue(0);
      translateY.setOffset(lastOffsetY.current);
      translateY.setValue(0);
    }
  };

  // Pinch event to scale the image
  const onPinchEvent = Animated.event([{ nativeEvent: { scale: scale } }], {
    useNativeDriver: true,
  });

  // Handle end of pinch (zoom) gesture
  const onPinchStateChange = (event) => {
    if (event.nativeEvent.state === State.END) {
      Animated.spring(scale, {
        toValue: 1,
        useNativeDriver: true,
        bounciness: 1,
      }).start();
    }
  };

  return (
    <View style={styles.container}>
      <PanGestureHandler
        onGestureEvent={onPanEvent}
        onHandlerStateChange={onPanStateChange}
      >
        <Animated.View>
          <PinchGestureHandler
            onGestureEvent={onPinchEvent}
            onHandlerStateChange={onPinchStateChange}
          >
            <Animated.Image
              source={{ uri: imageUri }}
              style={[
                styles.image,
                {
                  transform: [
                    { scale: scale },
                    { translateX: translateX },
                    { translateY: translateY },
                  ],
                },
              ]}
            />
          </PinchGestureHandler>
        </Animated.View>
      </PanGestureHandler>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F7F9FC",
  },
  image: {
    width: width,
    height: height / 2,
    resizeMode: "contain",
  },
});

export default DisplayImage;
