import React, { useState, useEffect, useRef } from "react";
import {
  StyleSheet,
  Alert,
  TouchableOpacity,
  Image,
  Platform,
  View,
} from "react-native";
import {
  Input,
  Button,
  Layout,
  Text,
  Spinner,
  ProgressBar,
} from "@ui-kitten/components";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import { useAuth } from "./ThemeContext";
import * as Device from "expo-device";
import * as Notifications from "expo-notifications";
//import Constants from 'expo-constants';
import * as TaskManager from "expo-task-manager";
const BACKGROUND_NOTIFICATION_TASK = "BACKGROUND-NOTIFICATION-TASK";

// defines how device should handle a notification when the app is running (foreground notifications)
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
  }),
});

const handleNewNotification = async (notificationObject) => {
  try {
    const newNotification = {
      id: notificationObject.messageId,
      date: notificationObject.sentTime,
      title: notificationObject.data.title,
      body: notificationObject.data.message,
      data: JSON.parse(notificationObject.data.body),
    };
    // add the code to do what you need with the received notification  and, e.g., set badge number on app icon
    console.log(newNotification);
    alert(notificationObject.data.message);
    //await Notifications.setBadgeCountAsync(1)
  } catch (error) {
    console.error(error);
  }
};

TaskManager.defineTask(
  BACKGROUND_NOTIFICATION_TASK,
  ({ data, error, executionInfo }) => handleNewNotification(data.notification)
);

export async function registerForPushNotificationsAsync() {
  let token;

  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync("default", {
      name: "default",
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: "#FF231F7C",
    });
  }

  if (Device.isDevice) {
    const { status: existingStatus } =
      await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;
    if (existingStatus !== "granted") {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }
    if (finalStatus !== "granted") {
      alert("Failed to get push token for push notification!");
      return;
    }
    token = (
      await Notifications.getExpoPushTokenAsync({
        //projectId: Constants.easConfig.projectId, // you can hard code project id if you dont want to use expo Constants
        projectId: "e58b903f-9b45-4e40-83b7-e3631d8c3fb2", // you can hard code project id if you dont want to use expo Constants
      })
    ).data;
    console.log(token);
  } else {
    alert("Must use physical device for Push Notifications");
  }

  return token;
}

const LoginScreen = ({ navigation }) => {
  const [accesscode, setAccesscode] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loginLabel, setLoginLabel] = useState("LOGIN");
  const [loading, setLoading] = useState(false); // Loading state
  const [progress, setProgress] = useState(0); // Progress state
  const [isSelected, setIsSelected] = useState(false);
  const [expoPushToken, setExpoPushToken] = useState("");
  const [notification, setNotification] = useState(false);
  const notificationListener = useRef();
  const responseListener = useRef();

  const { setUrl, authUser, setAuthUser, isLoggedIn, setIsLoggedIn } =
    useAuth();

  const handlePressIn = () => {
    setIsSelected(true);
  };

  const handlePressOut = () => {
    setIsSelected(false);
  };

  useEffect(() => {
    // register task to run whenever is received while the app is in the background
    Notifications.registerTaskAsync(BACKGROUND_NOTIFICATION_TASK);

    registerForPushNotificationsAsync().then((token) =>
      setExpoPushToken(token)
    );

    notificationListener.current =
      Notifications.addNotificationReceivedListener((notification) => {
        setNotification(notification);
      });

    responseListener.current =
      Notifications.addNotificationResponseReceivedListener((response) => {
        console.log(response);
      });

    // listener triggered whenever a notification is received while the app is in the foreground
    const foregroundReceivedNotificationSubscription =
      Notifications.addNotificationReceivedListener((notification) => {
        handleNewNotification(notification.request.trigger.remoteMessage);
      });

    loadAccessCode();

    return () => {
      foregroundReceivedNotificationSubscription.remove();
      Notifications.unregisterTaskAsync(BACKGROUND_NOTIFICATION_TASK);
      Notifications.removeNotificationSubscription(
        notificationListener.current
      );
      Notifications.removeNotificationSubscription(responseListener.current);
    };
  }, []);

  const loadAccessCode = async () => {
    try {
      const savedAccessCode = await AsyncStorage.getItem("accesscode");
      if (savedAccessCode !== null) {
        setAccesscode(savedAccessCode);
        fCheckAccessCode(savedAccessCode);
      }
    } catch (error) {
      console.error("Failed to load access code", error);
    }
  };

  const saveAccessCode = async (acode) => {
    try {
      await AsyncStorage.setItem("accesscode", acode);
    } catch (error) {
      console.error("Failed to save access code", error);
    }
  };

  const saveUsername = async (user) => {
    try {
      await AsyncStorage.setItem("username", user);
    } catch (error) {
      console.error("Failed to save username", error);
    }
  };

  function fCheckAccessCode(acode) {
    var ucode = acode.toUpperCase();
    if (ucode === "ERQ2013") {
      setLoginLabel("CONTINUE");
    } else {
      setLoginLabel("LOGIN");
    }
    setAccesscode(ucode);
  }

  function fLogin() {
    if (accesscode === "ERQ2013" && loginLabel === "CONTINUE") {
      navigation.navigate("LoginSSO");
    }

    if (accesscode === "") {
      Alert.alert("You must specify an Access Code.");
      return;
    }
    if (username === "") {
      Alert.alert("You must specify a User Name.");
      return;
    }
    if (password === "") {
      Alert.alert("You must specify a Password.");
      return;
    }

    setLoading(true); // Start loading
    setProgress(0.3); // Example progress value, adjust based on your logic

    const conn = ""; //checkConnection();

    if (conn === "No network connection" || conn === "Unknown connection") {
      Alert.alert("You do not have an internet connection!");
      setLoading(false); // Stop loading
      setProgress(0); // Reset progress
    } else {
      const svr = accesscode.substring(0, 2).replace("0", ""); //remove leading zeros from the server: 02 becomes 2
      const talProd = "https://apps" + svr + ".talonsystems.com/";
      const localAcode = accesscode;

      var schema = "";
      // ERAU DEV
      if (localAcode.substring(0, 3).toUpperCase() === "ERD") {
        schema = "";
      } else if (localAcode.substring(0, 3).toUpperCase() === "ERQ") {
        schema = "";
      } else if (localAcode.substring(0, 3).toUpperCase() === "ERP") {
        schema = "";
      } else if (localAcode.substring(0, 6).toUpperCase() === "TALDEV") {
        schema = "";
      } else if (localAcode.substring(0, 6).toUpperCase() === "TALTST") {
        schema = "";
      } else {
        schema = localAcode.substring(2, 6);
      }

      if (
        accesscode.substring(0, 1).toUpperCase() !== "E" &&
        isNaN(accesscode)
      ) {
        Alert.alert(
          "You have entered an invalid access code. Only numeric characters are allowed."
        );
        setLoading(false); // Stop loading
        setProgress(0); // Reset progress
      } else if (
        accesscode.substring(0, 1).toUpperCase() !== "E" &&
        accesscode.substring(0, 2) !== "01" &&
        accesscode.substring(0, 2) !== "02" &&
        accesscode.substring(0, 2) !== "03" &&
        accesscode.substring(0, 2) !== "04" &&
        accesscode.substring(0, 2) !== "05" &&
        accesscode.substring(0, 2) !== "06" &&
        accesscode.substring(0, 2) !== "07" &&
        accesscode.substring(0, 2) !== "08" &&
        accesscode.substring(0, 2) !== "09" &&
        accesscode.substring(0, 2) !== "10" &&
        accesscode.substring(0, 2) !== "11" &&
        accesscode.substring(0, 2) !== "12"
      ) {
        Alert.alert("You have entered an invalid access code.");
        setLoading(false); // Stop loading
        setProgress(0); // Reset progress
      } else if (
        accesscode.substring(0, 1).toUpperCase() !== "E" &&
        accesscode.length !== 10
      ) {
        Alert.alert("You have entered an invalid access code.");
        setLoading(false); // Stop loading
        setProgress(0); // Reset progress
      } else {
        var url = talProd + "tseta/servlet/";
        var sHost = talProd + "tseta/servlet/";

        var sHostResURL =
          sHost +
          "content?module=home&page=m&reactnative=1&accesscode=" +
          accesscode +
          "&customer=eta" +
          schema +
          "&etamobilepro=1&nocache=n";
        var getURL =
          sHostResURL +
          "&mode=mLogin" +
          "&uname=" +
          username +
          "&password=" +
          password +
          "&expotoken=" +
          expoPushToken;

        fetch(getURL)
          .then((response) => response.json())
          .then((json) => {
            setLoading(false); // Stop loading
            setProgress(1); // Set progress to complete
            if (json.validated == "1") {
              json.host = sHost;
              setAuthUser(json);
              console.log(json);
              setIsLoggedIn(true);
              saveAccessCode(accesscode); // Save the access code on successful logins
              saveUsername(username);
            } else {
              Alert.alert("You are not authorized to access ETA.");
              setIsLoggedIn(false);
              setAuthUser(null);
            }
            return json;
          })
          .catch((error) => {
            setLoading(false); // Stop loading
            setProgress(0); // Reset progress
            Alert.alert(error.message);
            console.error(error.message);
          });
      }
    }
    setIsSelected(false);
  }

  return (
    <KeyboardAwareScrollView
      contentContainerStyle={{ flexGrow: 1 }}
      enableOnAndroid={true}
      enableAutomaticScroll={true}
    >
      <Layout style={styles.container}>
        <Image style={styles.image} source={require("../assets/login.png")} />
        <Input
          style={styles.input}
          value={accesscode}
          label="Access Code"
          placeholder="Enter your access code"
          returnKeyType={Platform.OS === "ios" ? "done" : "next"}
          onChangeText={(text) => fCheckAccessCode(text)}
        />
        <Input
          style={styles.input}
          value={username}
          label="Username"
          placeholder="Enter your username"
          returnKeyType={Platform.OS === "ios" ? "done" : "next"}
          onChangeText={(text) => setUsername(text)}
        />
        <Input
          style={styles.input}
          value={password}
          label="Password"
          placeholder="Enter your password"
          secureTextEntry={true}
          returnKeyType={Platform.OS === "ios" ? "done" : "next"}
          onChangeText={(text) => setPassword(text)}
        />
        {loading && (
          <ProgressBar
            style={styles.progressBar}
            progress={progress}
            status="primary"
          />
        )}
        <Button
          style={[
            styles.button,
            isSelected && styles.buttonSelected, // Apply selected styles
          ]}
          onPressIn={handlePressIn} // Trigger when button is pressed
          onPressOut={handlePressOut} // Trigger when button is released
          onPress={fLogin}
        >
          Login
        </Button>
        <TouchableOpacity onPress={() => navigation.navigate("LoginSSO")}>
          <Text style={styles.sso}>SSOLOGIN</Text>
        </TouchableOpacity>
      </Layout>
    </KeyboardAwareScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 16,
  },
  image: {
    width: 300,
    height: 300,
  },
  input: {
    marginVertical: 8,
    width: "100%",
  },
  progressBar: {
    marginVertical: 16,
    width: "100%",
  },
  button: {
    marginTop: 16,
    width: "100%",
    backgroundColor: "#0c4bc9",
    borderColor: "#0c4bc9",
  },
  sso: {
    marginTop: 8,
    color: "#b6daf2",
  },
  buttonSelected: {
    backgroundColor: "#5a8db0", // Darker shade when selected
    borderColor: "#5a8db0",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 5,
  },
});

export default LoginScreen;
