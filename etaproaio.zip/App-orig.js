import React from "react";
import { Router } from "./routes/Route";
import { AuthProvider } from "./screens/ThemeContext";
import * as eva from "@eva-design/eva";
import { ApplicationProvider,IconRegistry } from "@ui-kitten/components";
import { EvaIconsPack } from "@ui-kitten/eva-icons";
import "react-native-gesture-handler";//hopefully will fix eas build apk crashing when try to run; base of stackoverflow

export default function App() {
 return (
  <>  
  <ApplicationProvider{...eva} theme={eva.light}>
    <IconRegistry icons={EvaIconsPack}/>
    <AuthProvider>
    <Router />
    </AuthProvider>
    </ApplicationProvider>
  </>

   );
}