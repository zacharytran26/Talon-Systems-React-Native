import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import MessagesScreen from "../screens/MessageScreens/MessageListScreen"; // Assuming you have a MessagesScreen
import InstructorsScreen from "../screens/MessageScreens/InstructorScreen";
import EmailList from "../screens/MessageScreens/EmailDetailsScreen";
import { ReplyScreen } from "../screens/MessageScreens/ReplyScreen";
import StudentsScreen from "../screens/MessageScreens/StudentScreen";
import InstructorList from "../screens/MessageScreens/InstructorDetailScreen";
import StudentList from "../screens/MessageScreens/StudentDetailScreen";
import LogoutScreen from "../screens/MessageScreens/Logout";
import NewMessage from "../screens/MessageScreens/NewMessageScreen";
import StudentCourse from "../screens/MessageScreens/StudentCourseScreen";
import StudentMap from "../screens/MessageScreens/StudentMap";
import StudentMapDetails from "../screens/MessageScreens/StudentMapsDetail";
import LineItem from "../screens/MessageScreens/LineItems";
import Approve from "../screens/MessageScreens/ApprovalScreen";
import Times from "../screens/MessageScreens/TimesScreen";
import DisplayImage from "../screens/MessageScreens/ImageScreen";
import InstructorActivity from "../screens/MessageScreens/InstructorActivity";
import ConfirmFIF from "../screens/MessageScreens/ConfirmationFIF";
import SettingsScreen from "../screens/MessageScreens/SettingScreen";
import PendingAuths from "../screens/MessageScreens/PendingAuths";
import FIFScreen from "../screens/MessageScreens/FIFScreen";
import LogScreen from "../screens/MessageScreens/LogScreen";
const Stack = createNativeStackNavigator();

export default function MessagesStackNavigator() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: true, //has the back button
        headerBackTitleVisible: false,
        headerStyle: {
          backgroundColor: "#f7f9fc",
        },
        headerTitle: "",
      }}
    >
      <Stack.Screen name="Messages" component={MessagesScreen} />
      <Stack.Screen name="MessageReplyScreen" component={ReplyScreen} />
      <Stack.Screen name="MessageEmails" component={EmailList} />
      <Stack.Screen name="MessageNewMessage" component={NewMessage} />
      <Stack.Screen
        name="MessageInstructorScreen"
        component={InstructorsScreen}
      />
      <Stack.Screen name="MessageStudentScreen" component={StudentsScreen} />
      <Stack.Screen
        name="MessageInstructorDetailScreen"
        component={InstructorList}
      />
      <Stack.Screen name="MessageStudentDetailScreen" component={StudentList} />
      <Stack.Screen name="MessageLogout" component={LogoutScreen} />
      <Stack.Screen name="MessageStudentCourse" component={StudentCourse} />
      <Stack.Screen name="MessageStudentMap" component={StudentMap} />
      <Stack.Screen
        name="MessageStudentMapDetails"
        component={StudentMapDetails}
      />
      <Stack.Screen name="MessageLineItem" component={LineItem} />
      <Stack.Screen name="MessageAuth" component={Approve} />
      <Stack.Screen name="MessageTimes" component={Times} />
      <Stack.Screen name="MessageImage" component={DisplayImage} />
      <Stack.Screen
        name="MessageActivityApproval"
        component={ApproveActivity}
      />
      <Stack.Screen name="MessageConfirm" component={ConfirmFIF} />
      <Stack.Screen
        name="MessageInstructorActivity"
        component={InstructorActivity}
      />
      <Stack.Screen name="MessageLog" component={LogScreen} />
      <Stack.Screen name="MessageSettings" component={SettingsScreen} />
      <Stack.Screen name="MessagePendingAuth" component={PendingAuths} />
      <Stack.Screen name="MessageFIF" component={FIFScreen} />
    </Stack.Navigator>
  );
}
