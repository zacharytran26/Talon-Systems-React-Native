// import React from "react";
// import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
// import {
//   BottomNavigation,
//   BottomNavigationTab,
//   Icon,
// } from "@ui-kitten/components";
// import HomeDrawerNavigator from "./HomeDrawer";
// import IssueDrawerNavigator from "./IssueDrawer";
// import CurrencyDrawerNavigator from "./CurrencyDrawer";
// import MessagesDrawerNavigator from "./MessagesDrawer";
// import QualiDrawerNavigator from "./QualiDrawer"; // Assuming this exists

// const { Navigator, Screen } = createBottomTabNavigator();

// const BottomTabBar = ({ navigation, state }) => {
//   const handleSelect = (index) => {
//     const selectedTab = state.routeNames[index];
//     const isCurrentTab = state.index === index;

//     if (isCurrentTab) {
//       navigation.reset({
//         index: 0,
//         routes: [{ name: selectedTab }],
//       });
//     } else {
//       // Navigate to the selected tab
//       navigation.navigate(selectedTab, {
//         logMessage: `Selected tab: ${selectedTab}`,
//       });
//     }
//   };

//   return (
//     <BottomNavigation selectedIndex={state.index} onSelect={handleSelect}>
//       <BottomNavigationTab
//         icon={(props) => <Icon {...props} name="home-outline" />}
//       />
//       <BottomNavigationTab
//         icon={(props) => <Icon {...props} name="alert-triangle-outline" />}
//       />
//       <BottomNavigationTab
//         icon={(props) => <Icon {...props} name="file-text-outline" />}
//       />
//       <BottomNavigationTab
//         icon={(props) => <Icon {...props} name="checkmark-circle-2-outline" />}
//       />
//       <BottomNavigationTab
//         icon={(props) => <Icon {...props} name="message-circle-outline" />}
//       />
//     </BottomNavigation>
//   );
// };

// export default function MainBottomNav() {
//   return (
//     <Navigator
//       tabBar={(props) => <BottomTabBar {...props} />}
//       screenOptions={{ headerShown: false }}
//     >
//       <Screen name="mHome" component={HomeDrawerNavigator} />
//       <Screen name="mIssue" component={IssueDrawerNavigator} />
//       <Screen name="mQualifications" component={QualiDrawerNavigator} />
//       <Screen name="mCurrency" component={CurrencyDrawerNavigator} />
//       <Screen name="mMessages" component={MessagesDrawerNavigator} />
//     </Navigator>
//   );
// }
// import React from "react";
// import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
// import {
//   BottomNavigation,
//   BottomNavigationTab,
//   Icon,
// } from "@ui-kitten/components";
// import HomeDrawerNavigator from "./HomeDrawer";
// import IssueDrawerNavigator from "./IssueDrawer";
// import CurrencyDrawerNavigator from "./CurrencyDrawer";
// import MessagesDrawerNavigator from "./MessagesDrawer";
// import QualiDrawerNavigator from "./QualiDrawer"; // Assuming this exists

// const { Navigator, Screen } = createBottomTabNavigator();

// const BottomTabBar = ({ navigation, state }) => {
//   const handleSelect = (index) => {
//     const selectedTab = state.routeNames[index];
//     const isCurrentTab = state.index === index;

//     if (isCurrentTab) {
//       navigation.reset({
//         index: 0,
//         routes: [{ name: selectedTab }],
//       });
//     } else {
//       // Navigate to the selected tab
//       navigation.navigate(selectedTab, {
//         logMessage: `Selected tab: ${selectedTab}`,
//       });
//     }
//   };

//   const renderIcon = (name, index) => (props) => {
//     // Set custom icon colors for specific tabs
//     let color;

//     if (index === 2) {
//       // Qualifications tab
//       color = "red";
//     } else if (index === 3) {
//       // Currency tab
//       color = "yellow";
//     } else {
//       // Default color logic for other tabs
//       color = state.index === index ? "blue" : "gray";
//     }

//     return <Icon {...props} name={name} fill={color} />;
//   };

//   return (
//     <BottomNavigation selectedIndex={state.index} onSelect={handleSelect}>
//       <BottomNavigationTab icon={renderIcon("home-outline", 0)} />
//       <BottomNavigationTab icon={renderIcon("alert-triangle-outline", 1)} />
//       <BottomNavigationTab icon={renderIcon("file-text-outline", 2)} />
//       <BottomNavigationTab icon={renderIcon("checkmark-circle-2-outline", 3)} />
//       <BottomNavigationTab icon={renderIcon("message-circle-outline", 4)} />
//     </BottomNavigation>
//   );
// };

// export default function MainBottomNav() {
//   return (
//     <Navigator
//       tabBar={(props) => <BottomTabBar {...props} />}
//       screenOptions={{ headerShown: false }}
//     >
//       <Screen name="mHome" component={HomeDrawerNavigator} />
//       <Screen name="mIssue" component={IssueDrawerNavigator} />
//       <Screen name="mQualifications" component={QualiDrawerNavigator} />
//       <Screen name="mCurrency" component={CurrencyDrawerNavigator} />
//       <Screen name="mMessages" component={MessagesDrawerNavigator} />
//     </Navigator>
//   );
// }
import React, { useState } from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Icon } from "@ui-kitten/components"; // You can replace this with any icon library if needed
import HomeDrawerNavigator from "./HomeDrawer";
import IssueDrawerNavigator from "./IssueDrawer";
import CurrencyDrawerNavigator from "./CurrencyDrawer";
import MessagesDrawerNavigator from "./MessagesDrawer";
import QualiDrawerNavigator from "./QualiDrawer";
import { useAuth } from "../screens/ThemeContext";

const Tab = createBottomTabNavigator();

export default function MainBottomNav() {
  const { tabBarBadge } = useAuth();

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName;
          let iconColor = focused ? "blue" : "gray"; // Default dynamic color change

          if (route.name === "mHome") {
            iconName = "home-outline";
            iconColor = focused ? "blue" : "gray"; // Active blue, inactive gray
          } else if (route.name === "mIssue") {
            iconName = "alert-triangle-outline";
            iconColor = focused ? "red" : "gray"; // Active red, inactive gray
          } else if (route.name === "mQualifications") {
            iconName = "file-text-outline";
            iconColor = focused ? "blue" : "gray"; // Active yellow, inactive gray
          } else if (route.name === "mCurrency") {
            iconName = "checkmark-circle-2-outline";
            if (tabBarBadge > 0) {
              iconColor = "red"; // If there are expired currencies, show red
            } else {
              iconColor = "yellow"; // Active green if focused, gray if not
            }
          } else if (route.name === "mMessages") {
            iconName = "message-circle-outline";
            iconColor = focused ? "blue" : "gray"; // Active orange, inactive gray
          }

          return (
            <Icon name={iconName} width={size} height={size} fill={iconColor} />
          );
        },
        tabBarActiveTintColor: "blue",
        tabBarInactiveTintColor: "gray",
        headerShown: false,
        tabBarShowLabel: false,
      })}
    >
      <Tab.Screen name="mHome" component={HomeDrawerNavigator} />
      <Tab.Screen name="mIssue" component={IssueDrawerNavigator} />
      <Tab.Screen name="mQualifications" component={QualiDrawerNavigator} />
      <Tab.Screen
        name="mCurrency"
        component={CurrencyDrawerNavigator}
        options={{
          tabBarBadge: tabBarBadge > 0 ? tabBarBadge : null,
          tabBarBadgeStyle: { backgroundColor: "red" },
        }}
      />
      <Tab.Screen name="mMessages" component={MessagesDrawerNavigator} />
    </Tab.Navigator>
  );
}
