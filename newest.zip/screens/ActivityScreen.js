import React, { useEffect } from "react";
import {
  StyleSheet,
  SafeAreaView,
  View,
  Platform,
  Alert,
  Linking,
} from "react-native";
import { Layout, Text, Card, Button, Icon } from "@ui-kitten/components"; // Import Button and Icon components
import { useRoute, useNavigation } from "@react-navigation/native";
import { FlashList } from "@shopify/flash-list";
import * as Calendar from "expo-calendar";

const Activity = () => {
  const route = useRoute();
  const { activity } = route.params;

  useEffect(() => {
    requestCalendarPermissions();
  }, []);

  const requestCalendarPermissions = async () => {
    const { status } = await Calendar.requestCalendarPermissionsAsync();
    if (status !== "granted") {
      Alert.alert(
        "Permission Denied",
        "Calendar permission is required to add events. Please enable it in the settings."
      );
      return false;
    }
    return true;
  };

  const openInBrowser = (url) => {
    Linking.canOpenURL(url)
      .then((supported) => {
        if (supported) {
          Linking.openURL(url);
        } else {
          console.warn("Don't know how to open URI: " + url);
        }
      })
      .catch((err) => console.error("An error occurred", err));
  };

  const getDefaultCalendarSource = async () => {
    if (Platform.OS === "ios") {
      const defaultCalendar = await Calendar.getDefaultCalendarAsync();
      return defaultCalendar.source;
    } else {
      return { isLocalAccount: true, name: "Expo Calendar" };
    }
  };

  const createCalendarEvent = async (title, startDate, endDate, notes) => {
    const calendarGranted = await requestCalendarPermissions();
    if (!calendarGranted) return;

    let calendarId;

    if (Platform.OS === "ios") {
      const defaultCalendarSource = await getDefaultCalendarSource();
      calendarId = await Calendar.createCalendarAsync({
        title: "My New Calendar",
        color: "blue",
        entityType: Calendar.EntityTypes.EVENT,
        sourceId: defaultCalendarSource.id,
        source: defaultCalendarSource,
        name: "My Internal Calendar",
        ownerAccount: "personal",
        accessLevel: Calendar.CalendarAccessLevel.OWNER,
      });
    } else {
      const calendars = await Calendar.getCalendarsAsync(
        Calendar.EntityTypes.EVENT
      );
      calendarId = calendars.find(
        (cal) => cal.accessLevel === Calendar.CalendarAccessLevel.OWNER
      )?.id;

      if (!calendarId) {
        Alert.alert("Error", "No suitable calendar found.");
        return;
      }
    }

    const eventId = await Calendar.createEventAsync(calendarId, {
      title: title,
      startDate: startDate,
      endDate: endDate,
      timeZone: "GMT", // Adjust this according to your needs
      notes: notes,
    });

    Alert.alert(
      "Event Created",
      `Event with ID ${eventId} created successfully!`
    );
  };

  const handleAddEvent = async () => {
    const startDate = new Date(activity.start);
    const endDate = new Date(activity.end);
    const title = activity.activitytype + "(" + activity.subtype + ")";
    const notes = activity.start + activity.end;
    await createCalendarEvent(title, startDate, endDate, notes);
  };

  const handleAuthEvent = async (schactid, requestid) => {
    navigation.navigate("ActivityApproval", {
      activity: { schactid, requestid },
    });
  };

  const navigation = useNavigation();

  const handleInstructorPress = (instructorId, picid) => {
    navigation.navigate("InstructorActivity", {
      activity: { instructorId, picid },
    });
  };

  const RenderActivity = ({ item }) => {
    return (
      <View>
        <View style={styles.sectionContainer}>
          <Text category="h5" style={styles.sectionHeader}>
            Activity Details
          </Text>
        </View>
        <Card style={styles.card}>
          <Button
            onPress={handleAddEvent}
            accessoryLeft={(props) => (
              <Icon {...props} name="calendar-outline" fill="#fff" />
            )}
            style={styles.button}
          >
            Add to Calendar
          </Button>
        </Card>

        <Card style={styles.card}>
          <Button
            onPress={handleAuthEvent}
            accessoryLeft={(props) => (
              <Icon {...props} name="unlock-outline" fill="#fff" />
            )}
            style={styles.button}
          >
            Authorize
          </Button>
        </Card>

        <Card style={styles.card}>
          <Button
            onPress={() => handleInstructorPress(item.instructor, item.picid)}
            accessoryLeft={(props) => (
              <Icon {...props} name="person-outline" fill="#fff" />
            )}
            style={styles.button}
          >
            PIC: {item.pic}
          </Button>
        </Card>

        <Card style={styles.card}>
          <Text category="p1" style={styles.cardText}>
            Status: {item.status}
          </Text>
          <Text category="p1" style={styles.cardText}>
            Activity Type: {item.activitytype}
          </Text>
          <Text category="p1" style={styles.cardText}>
            Activity Subtype: {item.subtype}
          </Text>
          <Text category="p1" style={styles.cardText}>
            Resource Type: {item.resourcetype}
          </Text>
          <Text category="p1" style={styles.cardText}>
            Resource: {item.resource}
          </Text>
        </Card>

        <View style={styles.sectionContainer}>
          <Text category="h5" style={styles.sectionHeader}>
            Times
          </Text>
        </View>

        <Card style={styles.card}>
          <Text category="p1" style={styles.cardText}>
            Event Start: {item.eventstart}
          </Text>
          <Text category="p1" style={styles.cardText}>
            Activity Start: {item.actstart}
          </Text>
          <Text category="p1" style={styles.cardText}>
            Activity Duration: {item.actdur}
          </Text>
          <Text category="p1" style={styles.cardText}>
            Activity Stop: {item.actstop}
          </Text>
          <Text category="p1" style={styles.cardText}>
            Event Stop: {item.eventstop}
          </Text>
        </Card>

        {item.s1 ? (
          <View>
            <View style={styles.sectionContainer}>
              <Text category="h5" style={styles.sectionHeader}>
                Student 1 Details
              </Text>
            </View>
            <Card style={styles.card}>
              <Text category="s1" style={styles.cardText}>
                Name: {item.s1}
              </Text>
            </Card>
            <Card style={styles.card}>
              <Text category="s1" style={styles.cardText}>
                Course: {item.course1}
              </Text>
            </Card>

            <Card style={styles.card}>
              <Text category="s1" style={styles.cardText}>
                Unit: {item.u1}
              </Text>
            </Card>
            <Card style={styles.card}>
              <Text category="s1" style={styles.cardText}>
                Open FIFs: {item.fif1}
              </Text>
            </Card>
            {item.gs1 ? (
              <Card style={styles.card}>
                <Text category="s1" style={styles.cardText}>
                  Gradesheet:{" "}
                  <Button
                    appearance="ghost"
                    onPress={() => openInBrowser(item.gs1)}
                    style={styles.linkButton}
                  >
                    View Gradesheet
                  </Button>
                </Text>
              </Card>
            ) : (
              <Card></Card>
            )}
          </View>
        ) : null}

        {item.s2 ? (
          <View>
            <View style={styles.sectionContainer}>
              <Text category="h5" style={styles.sectionHeader}>
                Student 2 Details
              </Text>
            </View>
            <Card style={styles.card}>
              <Text category="s2" style={styles.cardText}>
                Name: {item.s2}
              </Text>
            </Card>
            <Card style={styles.card}>
              <Text category="s2" style={styles.cardText}>
                Course: {item.course2}
              </Text>
            </Card>

            <Card style={styles.card}>
              <Text category="s2" style={styles.cardText}>
                Unit: {item.u2}
              </Text>
            </Card>
            <Card style={styles.card}>
              <Text category="s2" style={styles.cardText}>
                Open FIFs: {item.fif2}
              </Text>
            </Card>
            {item.gs2 ? (
              <Card style={styles.card}>
                <Text category="s2" style={styles.cardText}>
                  Gradesheet:{" "}
                  <Button
                    appearance="ghost"
                    onPress={() => openInBrowser(item.gs2)}
                    style={styles.linkButton}
                  >
                    View Gradesheet
                  </Button>
                </Text>
              </Card>
            ) : (
              <Card></Card>
            )}
          </View>
        ) : null}
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <FlashList
        data={[activity]} // Pass the activity data as an array
        renderItem={RenderActivity}
        keyExtractor={(item) => item.id}
        estimatedItemSize={100}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F7F9FC",
  },
  sectionContainer: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: "#E5E9F2",
    borderRadius: 8,
    marginVertical: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  sectionHeader: {
    fontWeight: "bold",
    color: "#2E3A59",
    fontSize: 20,
  },
  card: {
    marginHorizontal: 16,
    marginVertical: 8,
    borderRadius: 8,
    backgroundColor: "#FFFFFF",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  cardText: {
    color: "#2E3A59",
    fontSize: 16,
  },
  button: {
    marginVertical: 8,
  },
  linkButton: {
    marginTop: 4,
    color: "#3366FF",
  },
});

export default Activity;
