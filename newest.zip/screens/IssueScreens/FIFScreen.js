import React, { useState, useEffect, useCallback } from "react";
import {
  StyleSheet,
  SafeAreaView,
  View,
  StatusBar,
  Linking,
  Alert,
} from "react-native";
import { Layout, Text, Button, Icon, Card } from "@ui-kitten/components";
import { useAuth } from "../ThemeContext";
import { FlashList } from "@shopify/flash-list";
import { useFocusEffect, useRoute } from "@react-navigation/native";

const FIFScreen = ({ navigation }) => {
  const [fif, setFif] = useState([]);
  const [viewedItems, setViewedItems] = useState(new Set()); // Track viewed items
  const [fifcount, setFifCount] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const { authUser } = useAuth();
  const route = useRoute();

  useEffect(() => {
    fetchFif();
  }, []);

  useFocusEffect(
    useCallback(() => {
      if (route.params?.setrefresh) {
        fetchFif();
      }
    }, [route.params?.setrefresh])
  );

  const fetchFif = async () => {
    const url = `${authUser.host}content?module=home&page=m&reactnative=1&accesscode=0200006733&uname=duser&password=1234&session_id=${authUser.sessionid}&customer=eta0000&mode=getfif&etamobilepro=1&nocache=n&persid=${authUser.currpersid}`;
    const response = await fetch(url);
    const data = await response.json();

    // Check if data exists
    if (data.fifs && data.fifs.length > 0) {
      setFif(data.fifs);
      setFifCount(data.fifs.length);
    } else {
      setFif([]); // Ensure fif state is empty if no data
      setFifCount(0);
    }
  };

  const handleConfirm = (item) => {
    if (!viewedItems.has(item.ID)) {
      Alert.alert("Please press View to confirm FIF");
    } else {
      navigation.navigate("IssueConfirm", { fifdata: fif });
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchFif();
    setRefreshing(false);
  };

  const openInBrowser = (url, item) => {
    Linking.canOpenURL(url)
      .then((supported) => {
        if (supported) {
          Linking.openURL(url);
          setViewedItems((prev) => new Set(prev).add(item.ID)); // Mark item as viewed
          handleRefresh(); // Automatically refresh the page after viewing
        } else {
          console.warn("Don't know how to open URI: " + url);
        }
      })
      .catch((err) => console.error("An error occurred", err));
  };

  const renderFif = ({ item }) => {
    const isViewed = viewedItems.has(item.ID); // Check if item is viewed

    return (
      <Card
        style={styles.card}
        status="basic"
        header={() => (
          <View style={styles.cardHeader}>
            <Text style={styles.cardHeaderText}>{item.DIS}</Text>
          </View>
        )}
      >
        <Text style={styles.descriptionText}>{item.DESCRIP}</Text>
        <View style={styles.buttonRow}>
          <Button
            style={styles.viewButton}
            status="primary"
            appearance="ghost"
            accessoryLeft={(props) => <Icon {...props} name="eye-outline" />}
            onPress={() => openInBrowser(item.LINK, item)} // Pass the item to mark it as viewed
          >
            View
          </Button>
          <Button
            style={styles.confirmButton}
            status="success"
            accessoryLeft={(props) => (
              <Icon {...props} name="checkmark-outline" />
            )}
            disabled={!isViewed} // Disable until item is viewed
            onPress={() => handleConfirm(item)}
          >
            Confirm
          </Button>
        </View>
      </Card>
    );
  };

  return (
    <Layout style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f7f9fc" />
      <SafeAreaView style={{ flex: 1 }}>
        <Text category="h5" style={styles.headerText}>
          FIF Count: {fifcount}
        </Text>

        {/* Check if there's no FIF data */}
        {fif.length === 0 ? (
          <View style={styles.noDataContainer}>
            <Text style={styles.noDataText}>No FIFs available</Text>
          </View>
        ) : (
          <FlashList
            data={fif}
            renderItem={renderFif}
            keyExtractor={(item) => item.ID.toString()}
            refreshing={refreshing}
            onRefresh={handleRefresh}
            contentContainerStyle={styles.list}
            estimatedItemSize={150}
          />
        )}
      </SafeAreaView>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 16,
    backgroundColor: "#f7f9fc",
  },
  headerText: {
    fontWeight: "bold",
    color: "#2E3A59",
    marginTop: 8,
  },
  card: {
    marginVertical: 8,
    borderRadius: 12,
    elevation: 3,
  },
  cardHeader: {
    padding: 12,
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
    backgroundColor: "#b6daf2",
  },
  cardHeaderText: {
    color: "#ffffff",
    fontWeight: "bold",
    fontSize: 16,
  },
  descriptionText: {
    marginVertical: 12,
    fontSize: 14,
    color: "#2E3A59",
  },
  buttonRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginVertical: 8,
  },
  viewButton: {
    flex: 0.48,
  },
  confirmButton: {
    flex: 0.48,
  },
  list: {
    paddingBottom: 20,
  },
  noDataContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  noDataText: {
    fontSize: 18,
    color: "#8F9BB3",
  },
});

export default FIFScreen;
