import React, { useState, useEffect, useCallback, useMemo } from "react";
import {
  View,
  Modal,
  TouchableOpacity,
  Text,
  StyleSheet,
  TouchableWithoutFeedback,
  Alert,
} from "react-native";
import { TimelineCalendar } from "@howljs/calendar-kit";
import { useAuth } from "./ThemeContext";
import { Toggle } from "@ui-kitten/components";
import { useNavigation } from "@react-navigation/native";
import { SafeAreaView } from "react-native";

const TimelineCalendarScreen = ({ updateBadgeCount }) => {
  const { authUser, setTabBarBadge } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [events, setEvents] = useState([]);
  const [viewMode, setViewMode] = useState("threeDays");
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const navigation = useNavigation();

  const fetchCalData = useCallback(
    async (fromDate, toDate) => {
      try {
        const response = await fetch(
          `${authUser.host}content?module=home&page=m&reactnative=1&uname=${
            authUser.uname
          }&password=${authUser.upwd}&customer=eta${
            authUser.schema
          }&session_id=${
            authUser.sessionid
          }&mode=getactivities&etamobilepro=1&nocache=${
            Math.random().toString().split(".")[1]
          }&persid=${authUser.currpersid}&calstart=${fromDate}&calend=${toDate}`
        );

        const textData = await response.text();
        console.log("TestRaw response data:", textData);

        let jsonData;

        try {
          jsonData = JSON.parse(textData);
        } catch (parseError) {
          const jsonStart = textData.indexOf("{");
          const jsonEnd = textData.lastIndexOf("}") + 1;
          const jsonString = textData.substring(jsonStart, jsonEnd);
          jsonData = JSON.parse(jsonString);
        }

        if (jsonData.expiredcurrency > 0) {
          setTabBarBadge(jsonData.expiredcurrency);
        } else {
          setTabBarBadge(jsonData.expiringcurrency);
        }

        const fetchedEvents = jsonData.activities.map((item) => ({
          id: Math.random().toString(36).slice(2, 10),
          start: new Date(item.start),
          end: new Date(item.end),
          title: item.summary,
          summary: item.summary,
          color: item.color,
          ...item,
        }));

        return fetchedEvents;
      } catch (error) {
        console.error("Fetching or parsing error:", error);
        return Alert.alert("Error fetching or parsing", error);
      }
    },
    [authUser]
  );

  const loadEventsForDateRange = useCallback(
    async (fromDate, toDate) => {
      setIsLoading(true);
      const events = await fetchCalData(
        fromDate.toISOString().split("T")[0],
        toDate.toISOString().split("T")[0]
      );
      setEvents(events);
      setIsLoading(false);
    },
    [fetchCalData]
  );

  useEffect(() => {
    const numOfDays = 7;
    const fromDate = new Date();
    const toDate = new Date();
    toDate.setDate(fromDate.getDate() + numOfDays);

    loadEventsForDateRange(fromDate, toDate);
  }, [authUser, loadEventsForDateRange]);

  const handlePress = useCallback(
    (event) => {
      navigation.navigate("Activity", {
        activity: {
          ...event,
          start: event.start,
          end: event.end,
        },
      });
    },
    [navigation]
  );

  const handleLongPress = useCallback((event) => {
    setSelectedEvent(event);
    setModalVisible(true);
  }, []);

  const handlePressModal = useCallback(() => {
    if (selectedEvent) {
      navigation.navigate("Activity", {
        activity: {
          ...selectedEvent,
          start: selectedEvent.start,
          end: selectedEvent.end,
        },
      });
      closeModal(); // Close the modal after navigating
    }
  }, [navigation, selectedEvent]);

  const closeModal = useCallback(() => {
    setModalVisible(false);
    setSelectedEvent(null);
  }, []);

  const handleDateChanged = useCallback(
    (date) => {
      const fromDate = new Date(date);
      const toDate = new Date(date);
      toDate.setDate(toDate.getDate() + 6); // Fetch events for the next 6 days (including the selected date)

      loadEventsForDateRange(fromDate, toDate);
    },
    [loadEventsForDateRange]
  );

  const toggleViewMode = useCallback(() => {
    setViewMode((prevMode) => {
      const newMode = prevMode === "threeDays" ? "week" : "threeDays";
      if (newMode === "threeDays") {
        handleDateChanged(new Date()); // Reset to today's date
      }
      return newMode;
    });
  }, [handleDateChanged]);

  const modalContent = useMemo(
    () => (
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={closeModal}
      >
        <TouchableWithoutFeedback onPress={closeModal}>
          <View style={styles.modalOverlay}>
            <TouchableOpacity
              style={styles.modalView}
              onPress={handlePressModal}
            >
              {selectedEvent && (
                <>
                  <Text style={styles.modalTitle}>{selectedEvent.subtype}</Text>
                  {(selectedEvent.activitytype === "FLIGHT" &&
                    selectedEvent.subtype === "Admin") ||
                  selectedEvent.subtype === "Refresher" ||
                  selectedEvent.subtype === "Rental" ? (
                    <Text style={styles.modalText}>
                      PIC: {selectedEvent.pic}
                    </Text>
                  ) : (
                    <Text style={styles.modalText}>
                      Instructor: {selectedEvent.pic}
                    </Text>
                  )}
                  {selectedEvent.subtype === "Refresher" ||
                  selectedEvent.subtype === "Check Ride" ? (
                    <Text style={styles.modalText}>
                      Student: {selectedEvent.s1}
                    </Text>
                  ) : null}
                  <Text style={styles.modalText}>
                    Status: {selectedEvent.status}
                  </Text>
                  <Text style={styles.modalText}>
                    Type: {selectedEvent.activitytype}({selectedEvent.subtype})
                  </Text>
                  <Text style={styles.modalText}>
                    Aircraft: {selectedEvent.resource}
                  </Text>
                </>
              )}
            </TouchableOpacity>
          </View>
        </TouchableWithoutFeedback>
      </Modal>
    ),
    [modalVisible, selectedEvent, closeModal, handlePressModal]
  );

  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
      <SafeAreaView style={styles.toggleContainer}>
        <Text>View Mode: </Text>
        <Toggle checked={viewMode !== "threeDays"} onChange={toggleViewMode} />
      </SafeAreaView>
      <View>
        <Text>OPS CONDITION: FLYING</Text>
      </View>
      <TimelineCalendar
        viewMode={viewMode}
        events={events}
        isLoading={isLoading}
        onPressEvent={handlePress}
        onLongPressEvent={handleLongPress}
        onDateChanged={handleDateChanged}
        theme={{ loadingBarColor: "#D61C4E" }}
      />

      {modalContent}
    </View>
  );
};

const styles = StyleSheet.create({
  toggleContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10,
    marginTop: 10,
  },
  modalOverlay: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0, 0.5)",
  },
  modalView: {
    backgroundColor: "white",
    borderRadius: 20,
    padding: 35,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 15,
  },
  modalText: {
    marginBottom: 10,
    textAlign: "center",
  },
});

export default TimelineCalendarScreen;
