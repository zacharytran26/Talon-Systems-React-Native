// import React, { useState, useEffect, useCallback, useRef } from "react";
// import {
//   StyleSheet,
//   SafeAreaView,
//   View,
//   StatusBar,
//   Alert,
//   Modal,
// } from "react-native";
// import { Layout, Text, Button, Icon, Card } from "@ui-kitten/components";
// import { useAuth } from "./ThemeContext";
// import { FlashList } from "@shopify/flash-list";
// import { WebView } from "react-native-webview";
// import { useFocusEffect, useRoute } from "@react-navigation/native";
// import { handleFetchError } from "./ExtraImports";

// const FIFScreen = ({ navigation }) => {
//   const [fif, setFif] = useState([]);
//   // const [confirmedFif, setConfirmedFif] = useState([]);
//   const [viewedItems, setViewedItems] = useState(new Set()); // Track viewed items
//   const [fifcount, setFifCount] = useState(0);
//   const [refreshing, setRefreshing] = useState(false);
//   const [webViewVisible, setWebViewVisible] = useState(false); // Modal visibility
//   const [webViewUrl, setWebViewUrl] = useState(""); // URL for WebView
//   const { authUser, setAuthUser, setIsLoggedIn } = useAuth();
//   const route = useRoute();
//   const FIFref = useRef([]);

//   useEffect(() => {
//     fetchFif();
//     // const data = [
//     //   {
//     //     CONF: "02 JAN 2025",
//     //     CONFIRM_CODE: "1234",
//     //     DESCRIP: "testing list",
//     //     DIS: "mobile3",
//     //     ID: "2702",
//     //     LINK: "https://www.google.com",
//     //     confirm: "0",
//     //   },
//     //   {
//     //     CONF: "31 DEC 2024",
//     //     CONFIRM_CODE: "556",
//     //     DESCRIP: "656",
//     //     DIS: "455",
//     //     ID: "2582",
//     //     LINK: "5",
//     //     confirm: "0",
//     //   },
//     //   {
//     //     CONF: "23 OCT 2024",
//     //     CONFIRM_CODE: "abcd",
//     //     DESCRIP: "Runway Incursion 24R",
//     //     DIS: "Runway Incursion",
//     //     ID: "2525",
//     //     LINK: "http://talonsystems.com/taloneta",
//     //     confirm: "0",
//     //   },
//     //   {
//     //     CONF: "29 OCT 2024",
//     //     CONFIRM_CODE: "abcd",
//     //     DESCRIP: "Runway Incursion 24R",
//     //     DIS: "Runway Incursion",
//     //     ID: "2522",
//     //     LINK: "http://talonsystems.com/taloneta",
//     //     confirm: "0",
//     //   },
//     // ];
//     // setFif(data);
//     // const count = data.filter((item) => item.confirm === "0").length;
//     // setFifCount(count);
//   }, []);
//   // useEffect(() => {
//   //   fetchFif();
//   //   //console.log("fif", fif);
//   //   //console.log("pop fif", fif.pop());
//   //   //if (removedid) {
//   //   //console.log("Remove ID received:", removedid);
//   //   //handleRemoval(removedid); // Call your function with the parameter
//   //   //console.log("Remove ID received:", fif);
//   //   //}
//   //   console.log("updated FIF:", updatedFIF);
//   //   setFif(updatedFIF);
//   // }, []); // Trigger effect when removeid changes
//   // useFocusEffect(
//   //   useCallback(() => {
//   //     if (route.params?.FifID) {
//   //       setFif((prevFif) => prevFif.filter((item) => item.ID !== FifID));
//   //       setFifCount((prevCount) => prevCount - 1);
//   //     } else {
//   //       fetchFif();
//   //     }
//   //   }, [FifID])
//   // );
//   // useFocusEffect(
//   //   useCallback(() => {
//   //     if (route.params?.FifId) {
//   //       markAsConfirmed("2702");
//   //       // Refetch emails when the screen is focused and an email is deleted
//   //       const { id, confirm } = route.params.FifId;
//   //       console.log("ID:", id, "Confirm:", confirm);
//   //       console.log(route.params?.FifId);
//   //     }
//   //   }, [route.params?.FifId])
//   // );

//   const fetchFif = async () => {
//     const url = `${
//       authUser.host
//     }content?module=home&page=m&reactnative=1&uname=${
//       authUser.uname
//     }&password=${authUser.upwd}&customer=eta${authUser.schema}&session_id=${
//       authUser.sessionid
//     }&mode=getfif&etamobilepro=1&nocache=${
//       Math.random().toString().split(".")[1]
//     }&persid=${authUser.currpersid}`;
//     const response = await fetch(url);
//     const data = await response.json();
//     if (handleFetchError(data, setAuthUser, setIsLoggedIn)) {
//       return; // Stop further processing if an error is handled
//     }
//     if (data.fifs && data.fifs.length > 0) {
//       setFif(data.fifs);
//       setFifCount(data.fifs.length);
//     } else {
//       setFif([]); // Ensure fif state is empty if no data
//       setFifCount(0);
//     }
//   };
//   const handleConfirm = (item) => {
//     if (!viewedItems.has(item.ID)) {
//       Alert.alert("Please press View to confirm FIF");
//     } else {
//       navigation.navigate("Confirm", { fifdata: item });
//     }
//   };

//   const handleRefresh = async () => {
//     setRefreshing(true);
//     await fetchFif();
//     setRefreshing(false);
//   };

//   const openInWebView = async (url, item) => {
//     setWebViewUrl(url);
//     setWebViewVisible(true);
//     setViewedItems((prev) => new Set(prev).add(item.ID)); // Mark item as viewed
//     await fetchFif();
//   };

//   const markAsConfirmed = (id) => {
//     const updatedFIF = fif.map((item) =>
//       item.ID === id ? { ...item, confirm: "1" } : item
//     );
//     // 1 = confirmed 0 = not confirmed
//     setFif(updatedFIF);
//     console.log("Updated FIF (local variable):", updatedFIF);
//   };

//   // const filteredFif = fif.filter((fif) => fif.confirm === "0");
//   const renderFif = ({ item }) => {
//     const isViewed = viewedItems.has(item.ID); // Check if item is viewed

//     return (
//       <Card
//         style={styles.card}
//         status="basic"
//         header={() => (
//           <View style={styles.cardHeader}>
//             <Text style={styles.cardHeaderText}>{item.DIS}</Text>
//           </View>
//         )}
//       >
//         <Text style={styles.descriptionText}>{item.DESCRIP}</Text>
//         <View style={styles.buttonRow}>
//           <Button
//             style={styles.viewButton}
//             status="primary"
//             appearance="ghost"
//             accessoryLeft={(props) => <Icon {...props} name="eye-outline" />}
//             onPress={() => openInWebView(item.LINK, item)} // Open in WebView
//           >
//             View
//           </Button>
//           <Button
//             style={styles.confirmButton}
//             status="success"
//             accessoryLeft={(props) => (
//               <Icon {...props} name="checkmark-outline" />
//             )}
//             disabled={!isViewed} // Disable until item is viewed
//             onPress={() => handleConfirm(item)}
//           >
//             Confirm
//           </Button>
//         </View>
//       </Card>
//     );
//   };

//   return (
//     <Layout style={styles.container}>
//       <StatusBar barStyle="dark-content" backgroundColor="#f7f9fc" />
//       <SafeAreaView style={{ flex: 1 }}>
//         <Text category="h5" style={styles.headerText}>
//           FIF: {fifcount}
//         </Text>

//         {fif.length === 0 ? (
//           <View style={styles.noDataContainer}>
//             <Text style={styles.noDataText}>No FIFs available</Text>
//           </View>
//         ) : (
//           <FlashList
//             data={fif}
//             renderItem={renderFif}
//             keyExtractor={(item) => item.ID.toString()}
//             refreshing={refreshing}
//             onRefresh={handleRefresh}
//             contentContainerStyle={styles.list}
//             estimatedItemSize={150}
//           />
//         )}

//         {/* WebView Modal */}
//         <Modal
//           visible={webViewVisible}
//           animationType="slide"
//           onRequestClose={() => setWebViewVisible(false)}
//         >
//           <SafeAreaView style={{ flex: 1 }}>
//             <View style={styles.webViewHeader}>
//               <Button onPress={() => setWebViewVisible(false)}>Close</Button>
//             </View>
//             <WebView source={{ uri: webViewUrl }} />
//           </SafeAreaView>
//         </Modal>
//       </SafeAreaView>
//     </Layout>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     paddingHorizontal: 16,
//     backgroundColor: "#f7f9fc",
//   },
//   headerText: {
//     fontWeight: "bold",
//     color: "#2E3A59",
//     marginTop: 8,
//   },
//   card: {
//     marginVertical: 8,
//     borderRadius: 12,
//     elevation: 3,
//   },
//   cardHeader: {
//     padding: 12,
//     borderTopLeftRadius: 12,
//     borderTopRightRadius: 12,
//     backgroundColor: "#b6daf2",
//   },
//   cardHeaderText: {
//     color: "#ffffff",
//     fontWeight: "bold",
//     fontSize: 16,
//   },
//   descriptionText: {
//     marginVertical: 12,
//     fontSize: 14,
//     color: "#2E3A59",
//   },
//   buttonRow: {
//     flexDirection: "row",
//     justifyContent: "space-between",
//     marginVertical: 8,
//   },
//   viewButton: {
//     flex: 0.48,
//   },
//   confirmButton: {
//     flex: 0.48,
//   },
//   list: {
//     paddingBottom: 20,
//   },
//   noDataContainer: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   noDataText: {
//     fontSize: 18,
//     color: "#8F9BB3",
//   },
//   webViewHeader: {
//     padding: 10,
//     backgroundColor: "#f7f9fc",
//     alignItems: "flex-end",
//   },
// });

// export default FIFScreen;
import React, { useState, useEffect, useCallback, useRef } from "react";
import {
  StyleSheet,
  SafeAreaView,
  View,
  StatusBar,
  Alert,
  Modal,
} from "react-native";
import { Layout, Text, Button, Icon, Card } from "@ui-kitten/components";
import { useAuth } from "./ThemeContext";
import { FlashList } from "@shopify/flash-list";
import { WebView } from "react-native-webview";
import { useFocusEffect, useRoute } from "@react-navigation/native";
import { handleFetchError } from "./ExtraImports";
const FIFScreen = ({ navigation }) => {
  const [fif, setFif] = useState([]);
  const [goFetch, setgoFetch] = useState(true);
  // const [confirmedFif, setConfirmedFif] = useState([]);
  const [viewedItems, setViewedItems] = useState(new Set()); // Track viewed items
  const [confirmedItems, setConfirmedItems] = useState(new Set());
  const [fifcount, setFifCount] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const [webViewVisible, setWebViewVisible] = useState(false); // Modal visibility
  const [webViewUrl, setWebViewUrl] = useState(""); // URL for WebView
  const { authUser, setAuthUser, setIsLoggedIn } = useAuth();
  const route = useRoute();
  const fifRef = useRef([]);
  //var goFetch = true;
  useEffect(() => {
    if (goFetch) {
      fetchFif();
    }
  }, [goFetch]);


  useFocusEffect(
    //useref fif should have original list?

    useCallback(() => {
      // if (route.params?.isConfirmed) {
      //   const { id } = route.params.FifId;

      //   let newFif = fifRef.current.filter((fif) => {
      //     //console.log("fif.ID", fif.ID);
      //     return fif.ID !== id;
      //   });

      //   setFif(newFif);

      //   setgoFetch(false);
      // }
      if (route.params?.isConfirmed){
        const { id } = route.params.FifId;
        const result = fif.find((item) => item.ID === id)
        setConfirmedItems((prev) => new Set(prev).add(result));
        handleRefresh();
      }

    }, [route.params?.isConfirmed]) // Dependency array excludes `fif` but includes `fifRef`
  );

  const fetchFif = async () => {
    const url = `${
      authUser.host
    }content?module=home&page=m&reactnative=1&uname=${
      authUser.uname
    }&password=${authUser.upwd}&customer=eta${authUser.schema}&session_id=${
      authUser.sessionid
    }&mode=getfif&etamobilepro=1&nocache=${
      Math.random().toString().split(".")[1]
    }&persid=${authUser.currpersid}`;
    const response = await fetch(url);
    const data = await response.json();
    if (handleFetchError(data, setAuthUser, setIsLoggedIn)) {
      return; // Stop further processing if an error is handled
    }
    if (data.fifs && data.fifs.length > 0) {
      setFif(data.fifs);
      fifRef.current = data.fifs;
      setFifCount(data.fifs.length);
    } else {
      setFif([]); // Ensure fif state is empty if no data
      setFifCount(0);
    }
  };
  const handleConfirm = (item) => {
    setConfirmedItems((prev) => new Set(prev).add(item.ID));
    //set useref to fif use state
    if (!viewedItems.has(item.ID)) {
      Alert.alert("Please press View to confirm FIF");
    } else {
      navigation.navigate("Confirm", { fifdata: item });
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchFif();
    setRefreshing(false);
  };

  const openInWebView = async (url, item) => {
    setWebViewUrl(url);
    setWebViewVisible(true);
    setViewedItems((prev) => new Set(prev).add(item.ID)); // Mark item as viewed
    await fetchFif();
  };

  const renderFif = ({ item }) => {
    const isViewed = viewedItems.has(item.ID); // Check if item is viewed
    const isConfirmed = confirmedItems.has(item.ID);
    return (
      <Card
        style={styles.card}
        status="basic"
        header={() => (
          <View style={styles.cardHeader}>
            <Text style={styles.cardHeaderText}>{item.DIS}</Text>
          </View>
        )}
      >
        <Text style={styles.descriptionText}>{item.DESCRIP}</Text>
        <View style={styles.buttonRow}>
          <Button
            style={styles.viewButton}
            status="primary"
            appearance="ghost"
            accessoryLeft={(props) => <Icon {...props} name="eye-outline" />}
            onPress={() => openInWebView(item.LINK, item)} // Open in WebView
          >
            View
          </Button>
            <Button
              style={styles.confirmButton}
              status="success"
              accessoryLeft={(props) => (
                <Icon {...props} name="checkmark-outline" />
              )}
              disabled={!isViewed || isConfirmed} // Disable until item is viewed
              onPress={() => handleConfirm(item)}
            >
              Confirm
            </Button>
          
        </View>
      </Card>
    );
  };

  return (
    <Layout style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f7f9fc" />
      <SafeAreaView style={{ flex: 1 }}>
        <Text category="h5" style={styles.headerText}>
          FIF: {fifcount}
        </Text>

        {fif.length === 0 ? (
          <View style={styles.noDataContainer}>
            <Text style={styles.noDataText}>No FIFs available</Text>
          </View>
        ) : (
          <FlashList
            data={fif}
            renderItem={renderFif}
            keyExtractor={(item) => item.ID.toString()}
            refreshing={refreshing}
            onRefresh={handleRefresh}
            contentContainerStyle={styles.list}
            estimatedItemSize={150}
          />
        )}

        {/* WebView Modal */}
        <Modal
          visible={webViewVisible}
          animationType="slide"
          onRequestClose={() => setWebViewVisible(false)}
        >
          <SafeAreaView style={{ flex: 1 }}>
            <View style={styles.webViewHeader}>
              <Button onPress={() => setWebViewVisible(false)}>Close</Button>
            </View>
            <WebView source={{ uri: webViewUrl }} />
          </SafeAreaView>
        </Modal>
      </SafeAreaView>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 16,
    backgroundColor: "#f7f9fc",
  },
  headerText: {
    fontWeight: "bold",
    color: "#2E3A59",
    marginTop: 8,
  },
  card: {
    marginVertical: 8,
    borderRadius: 12,
    elevation: 3,
  },
  cardHeader: {
    padding: 12,
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
    backgroundColor: "#b6daf2",
  },
  cardHeaderText: {
    color: "#ffffff",
    fontWeight: "bold",
    fontSize: 16,
  },
  descriptionText: {
    marginVertical: 12,
    fontSize: 14,
    color: "#2E3A59",
  },
  buttonRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginVertical: 8,
  },
  viewButton: {
    flex: 0.48,
  },
  confirmButton: {
    flex: 0.48,
  },
  list: {
    paddingBottom: 20,
  },
  noDataContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  noDataText: {
    fontSize: 18,
    color: "#8F9BB3",
  },
  webViewHeader: {
    padding: 10,
    backgroundColor: "#f7f9fc",
    alignItems: "flex-end",
  },
});

export default FIFScreen;
