import React, { useState } from "react";
import {
  SafeAreaView,
  TouchableOpacity,
  Image,
  StyleSheet,
  View,
  Linking,
} from "react-native";
import {
  createDrawerNavigator,
  DrawerContentScrollView,
  DrawerItem,
} from "@react-navigation/drawer";

import { useTheme, Avatar, Text } from "@ui-kitten/components";
import { useAuth } from "../screens/ThemeContext";

import StudentsScreen from "../screens/StudentScreen";
import InstructorsScreen from "../screens/InstructorScreen";
import HomeScreen from "../screens/HomeScreen";
import LogoutScreen from "../screens/Logout";
import SettingsScreen from "../screens/SettingScreen";
import PendingAuths from "../screens/PendingAuths";
import FIFScreen from "../screens/FIFScreen";
import LogScreen from "../screens/LogScreen";
import QualiScreen from "../screens/QualificationScreen";

import * as ImagePicker from "expo-image-picker";

const Drawer = createDrawerNavigator();

export function CustomDrawerContentCurrency(props) {
  const theme = useTheme();
  const { authUser } = useAuth();
  const [uploadedImageUri, setUploadedImageUri] = useState(null);
  const uric = `https://apps5.talonsystems.com/tseta/php/upload/view.php?imgRes=10&viewPers=${authUser.currpersid}&rorwwelrw=rw&curuserid=${authUser.currpersid}&id=${authUser.sysdocid}&svr=${authUser.svr}&s=${authUser.sessionid}&c=eta${authUser.schema}`;

  const openImagePickerExpo = async (selectedQual) => {
    const permissionResult =
      await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (permissionResult.granted === false) {
      alert("Permission to access camera roll is required!");
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.canceled) {
      const imageUri = result.assets[0].uri;
      setUploadedImageUri(imageUri);
      const formData = new FormData();
      formData.append("photo", {
        uri: imageUri,
        type: "image/jpeg",
        name: result.assets[0].fileName,
      });

      let usertype = "";
      if (authUser.perstype === "student") {
        usertype = "stud";
      } else if (authUser.perstype === "instructor") {
        usertype = "inst";
      } else {
        usertype = "other";
      }
      formData.append("pers_id", authUser.currpersid);
      formData.append("pers_type", `${usertype}`);
      formData.append("any_type", "pers_id");
      formData.append("any_id", authUser.currpersid);
      formData.append("doc_type", `${usertype}` + "ProfilePic");
      formData.append("title", "PersonProfile");
      formData.append("file_type", result.assets[0].type);
      formData.append("etaaction", "new");

      const myurl = `${authUser.host}uploadBlobETAAll`;

      try {
        const response = await fetch(myurl, {
          method: "POST",
          body: formData,
          headers: {
            "Content-Type": "multipart/form-data;",
          },
        });

        if (response.ok) {
          setUploadedImageUri(result.assets[0].uri);
          alert("Image uploaded successfully!");
        } else {
          alert("Image upload failed.");
        }
      } catch (error) {
        console.log("error", error);
        alert("An error occurred during the image upload.");
      }
    }
  };

  const openInBrowser = (url) => {
    Linking.canOpenURL(url)
      .then((supported) => {
        if (supported) {
          Linking.openURL(url);
        } else {
          console.warn("Don't know how to open URI: " + url);
        }
      })
      .catch((err) => console.error("An error occurred", err));
  };
  return (
    <DrawerContentScrollView
      {...props}
      style={{ backgroundColor: theme["color-basic-300"] }}
      showsVerticalScrollIndicator={false}
    >
      <SafeAreaView>
        <TouchableOpacity
          appearance="ghost"
          style={styles.profileSection}
          onPress={openImagePickerExpo}
        >
          <Avatar
            source={
              uploadedImageUri ? { uri: uploadedImageUri } : { uri: uric }
            }
            style={styles.profileAvatar}
          />
        </TouchableOpacity>
        <DrawerItem
          label="ETA"
          onPress={() =>
            openInBrowser(
              `${authUser.host}content?module=home&page=homepg&session_id=${authUser.sessionid}&uname=${authUser.uname}`
            )
          }
        />
        <DrawerItem
          label="FIF"
          onPress={() => props.navigation.navigate("CFIF")}
        />
        <DrawerItem
          label="Full Calendar"
          onPress={() =>
            openInBrowser(
              `${authUser.host.replace(
                "servlet/",
                ""
              )}php/fullcalendar/demos/default.php?url=${
                authUser.host
              }content?module=home&curDate=16/SEP/2024&schedDate=9/16/2024&uname=${
                authUser.uname
              }&page=m&session_id=${
                authUser.sessionid
              }&mode=mGetMonthEvents&start=2024-07-28&end=2024-09-08&_=1726577034553&etamobilepro=1&nocache=1726513674752&hash=${
                authUser.hash
              }`
            )
          }
        />
        <DrawerItem
          label="Instructors"
          onPress={() => props.navigation.navigate("CInstructorScreen")}
          initialParams={{ drawerContext: "CurrencyDrawer" }}
        />
        <DrawerItem
          label="Logbook"
          onPress={() =>
            openInBrowser(
              `${
                authUser.host
              }content?module=home&curDate=16/SEP/2024&schedDate=9/16/2024&uname=${
                authUser.uname
              }&page=m&session_id=${
                authUser.sessionid
              }&mode=mMyLogBookInit&etamobilepro=1&nocache=${
                Math.random().toString().split(".")[1]
              }&hash=${authUser.hash}&customer=eta${
                authUser.schema
              }&zajael1120=${authUser.custhash}&`
            )
          }
        />
        <DrawerItem
          label="Pending Authorizations"
          onPress={() => props.navigation.navigate("CPendingAuth")}
        />
        <DrawerItem
          label="Scheduling"
          onPress={() =>
            openInBrowser(
              `${authUser.host}content?module=home&curDate=16/SEP/2024&schedDate=9/16/2024&uname=${authUser.uname}&page=m&session_id=${authUser.sessionid}&mode=mGetPreGantt&etamobilepro=1&nocache=1726513674752&hash=${authUser.hash}`
            )
          }
        />
        <DrawerItem
          label="Students"
          onPress={() => props.navigation.navigate("CStudentScreen")}
        />
        <DrawerItem
          label="Settings"
          onPress={() => props.navigation.navigate("CSettings")}
        />
        <DrawerItem
          label="Logout"
          onPress={() => props.navigation.navigate("CLogout")}
        />
        <View style={styles.bottomTextContainer}>
          <TouchableOpacity onPress={() => openInBrowser(authUser.LINK)}>
            <Text>Help</Text>
          </TouchableOpacity>
          <Text style={styles.bottomText}>Version 1.0.0</Text>
          <Text style={styles.bottomText}>© 2024 Talon Systems LLC</Text>
          <Text style={styles.bottomText}>All Rights Reserved</Text>
        </View>
      </SafeAreaView>
    </DrawerContentScrollView>
  );
}

function MainDrawer() {
  return (
    <Drawer.Navigator
      initialRouteName="Home"
      drawerContent={(props) => <CustomDrawerContentCurrency {...props} />}
      screenOptions={({ navigation }) => ({
        headerTitle: () => <LogoTitle navigation={navigation} />,
        headerStyle: { height: 150 },
        headerBackTitleVisible: false,
      })}
    >
      <Drawer.Screen name="Home" component={HomeScreen} />
      <Drawer.Screen name="InstructorScreen" component={InstructorsScreen} />
      <Drawer.Screen name="StudentScreen" component={StudentsScreen} />
      <Drawer.Screen name="Settings" component={SettingsScreen} />
      <Drawer.Screen name="Quali" component={QualiScreen} />
      <Drawer.Screen name="PendingAuth" component={PendingAuths} />
      <Drawer.Screen name="FIF" component={FIFScreen} />
      <Drawer.Screen name="Log" component={LogScreen} />
      <Drawer.Screen name="Logout" component={LogoutScreen} />
    </Drawer.Navigator>
  );
}

function LogoTitle({ navigation }) {
  return (
    <TouchableOpacity
      onPress={() =>
        navigation.reset({
          index: 0,
          routes: [{ name: "Drawer" }],
        })
      }
    >
      <Image
        style={{ width: 150, height: 50 }}
        source={require("../assets/logo.png")}
      />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  bottomTextContainer: {
    marginTop: "auto", // Pushes the text to the bottom
    alignItems: "center",
    paddingVertical: 230,
  },
  bottomText: {
    fontSize: 10,
    color: "#888", // Customize as needed
  },
  imagecontainer: {
    flex: 1,
    justifyContent: "center",
  },
  profileImage: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignSelf: "center",
    marginTop: 20,
    marginBottom: 20,
  },
  backgroundContainer: {
    flex: 1,
  },
  headerImage: {
    width: "80%",
    height: "100%",
    resizeMode: "contain",
  },
  headerContainer: {
    width: "100%",
    height: 60,
    justifyContent: "center",
    alignItems: "center",
  },
  profileAvatar: {
    width: 75,
    height: 75,
  },
  profileSection: {
    justifyContent: "center",
    alignItems: "center",
  },
});

export default MainDrawer;
