import React, { useState, useEffect } from "react";
import {
  StyleSheet,
  SafeAreaView,
  View,
  Platform,
  Alert,
  ScrollView,
} from "react-native";
import { Layout, Text, Button, Input, Icon } from "@ui-kitten/components";
import { useRoute } from "@react-navigation/native";
import { useAuth } from "./ThemeContext";

const useInputState = (initialValue = "") => {
  const [value, setValue] = useState(initialValue);
  return { value, onChangeText: setValue, reset: () => setValue(initialValue) };
};

const ConfirmFIF = ({ navigation }) => {
  const route = useRoute();
  const { fifdata } = route.params; // Passed JSON array with CONFIRM_CODE
  const pinInputState = useInputState(""); // Input for PIN
  const confirmInputState = useInputState("");
  const [confirm, setConfirm] = useState(false); // Determines if confirmation code is needed
  const { authUser } = useAuth();
  const [etaresponse, setEtaresponse] = useState(null); // Stores the response JSON
  const [responseData, setResponseData] = useState(null); // Stores response for display
  useEffect(() => {
    // Check if the confirmation code exists in the JSON data
    if (fifdata && fifdata[0].CONFIRM_CODE) {
      setConfirm(true); // Show confirmation code input if CONFIRM_CODE is present
    } else {
      setConfirm(false); // Hide confirmation code input if CONFIRM_CODE is not present
    }
  }, [fifdata]);

  const HandleAuthorization = async (approved) => {
    const confirmcode = confirmInputState.value;
    const pin = pinInputState.value;

    const response = await fetch(
      `${authUser.host}content?module=home&page=m&reactnative=1&uname=${
        authUser.uname
      }&password=${authUser.upwd}&customer=eta${authUser.schema}&session_id=${
        authUser.sessionid
      }&mode=confirmfif&etamobilepro=1&nocache=${
        Math.random().toString().split(".")[1]
      }&pinnum=${pin}&confirmcode=${confirmcode}&persid=${
        authUser.currpersid
      }&fifid=${fifdata[0].ID}`,
      {
        method: "POST",
        headers: {
          Accept: "application/txt",
          "Content-Type": "application/txt",
        },
      }
    );

    const data = await response.json();
    setEtaresponse(data); // Store response in state for further use
    setResponseData(data); // Store response data for UI display
  };

  useEffect(() => {
    // Check if etaresponse is present and the status is 'confirm'
    if (etaresponse && etaresponse.status === "confirm") {
      AlertMessage(etaresponse.msg); // Display success message
    }
  }, []);

  const AlertMessage = (message) => {
    Alert.alert("Status", message); // Show the alert with the message
  };

  const handleInput = () => {
    if (confirmInputState.value === fifdata[0].CONFIRM_CODE) {
      Alert.alert("Success", "Confirmation code is correct.");
    } else {
      Alert.alert("Error", "Confirmation code is incorrect.");
    }
  };

  return (
    <Layout style={styles.container}>
      <SafeAreaView>
        <View style={styles.content}>
          {confirm && (
            <Input
              multiline={false}
              textStyle={styles.textArea}
              placeholder="Confirmation Code"
              returnKeyType={Platform.OS === "ios" ? "done" : "next"}
              blurOnSubmit={true}
              {...confirmInputState}
              style={styles.input}
            />
          )}

          <Input
            multiline={false}
            textStyle={styles.textArea}
            placeholder="Pin"
            returnKeyType={Platform.OS === "ios" ? "done" : "next"}
            blurOnSubmit={true}
            {...pinInputState}
            style={styles.input}
            secureTextEntry={true}
            accessoryRight={(props) => <Icon {...props} name="lock-outline" />}
          />
          <View style={styles.buttonContainer}>
            <Button
              style={styles.approveButton}
              status="success"
              onPress={() => {
                // Only check confirmation code if it's required
                if (confirm) {
                  handleInput();
                  navigation.navigate("FIF", { setrefresh: true });
                }
                HandleAuthorization("approve");
              }}
            >
              Confirm
            </Button>
            <Button
              style={styles.cancelButton}
              appearance="outline"
              onPress={() => {
                navigation.goBack();
              }}
            >
              Cancel
            </Button>
          </View>
        </View>
      </SafeAreaView>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: "#f7f9fc",
  },
  content: {
    paddingHorizontal: 16,
  },
  textArea: {
    minHeight: 64,
  },
  input: {
    borderColor: "#E4E9F2",
    marginBottom: 16,
    borderRadius: 8,
  },
  buttonContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginTop: 16,
  },
  approveButton: {
    backgroundColor: "#4CAF50",
    borderColor: "#4CAF50",
    borderRadius: 8,
  },
  cancelButton: {
    borderColor: "#3366FF",
    borderRadius: 8,
  },
  jsonContainer: {
    marginTop: 20,
    padding: 10,
    backgroundColor: "#f0f0f0",
    borderRadius: 8,
  },
  jsonText: {
    fontSize: 12,
    color: "#333",
  },
});

export default ConfirmFIF;
