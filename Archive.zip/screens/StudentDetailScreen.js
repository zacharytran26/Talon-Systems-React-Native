import React, { useEffect, useState } from "react";
import {
  StyleSheet,
  SafeAreaView,
  View,
  TouchableOpacity,
  Alert,
  ScrollView,
  Linking,
  Platform,
} from "react-native";
import {
  Layout,
  Text,
  Avatar,
  Card,
  Button,
  ButtonGroup,
  Icon,
} from "@ui-kitten/components";
import { useRoute } from "@react-navigation/native";
import { useAuth } from "./ThemeContext";
import * as Contacts from "expo-contacts";

const StudentDetailScreen = ({ navigation }) => {
  const route = useRoute();
  const { detail } = route.params;
  const [image, setImage] = useState(null);
  const [studDetail, setStudDetail] = useState({});
  const { authUser } = useAuth();

  const uric = `${authUser.host.replace(
    "servlet/",
    ""
  )}/php/upload/view.php?imgRes=10&viewPers=${
    authUser.currpersid
  }&rorwwelrw=rw&curuserid=${authUser.currpersid}&id=${
    studDetail.SYSDOCID
  }&svr=${authUser.svr}&s=${authUser.sessionid}&c=eta${authUser.schema}`;

  useEffect(() => {
    fetchStudentDetails();
    (async () => {
      try {
        const { status } = await Contacts.requestPermissionsAsync();
        if (status !== "granted") {
          Alert.alert("Permission denied", "Unable to access contacts.");
        }
      } catch (error) {
        console.error("Error requesting permissions:", error);
        Alert.alert("Error", "An error occurred while requesting permissions.");
      }
    })();
  }, []);

  const fetchStudentDetails = async () => {
    try {
      const response = await fetch(
        `${authUser.host}content?module=home&page=m&reactnative=1&uname=${
          authUser.uname
        }&password=${authUser.upwd}&customer=eta${authUser.schema}&session_id=${
          authUser.sessionid
        }&mode=getstudentdetail&etamobilepro=1&nocache=${
          Math.random().toString().split(".")[1]
        }&persid=${authUser.currpersid}&persregid=${detail.id}`
      );
      const data = await response.json();
      setStudDetail(data);
    } catch (error) {
      Alert.alert("Error", error.message || "An error occurred");
    }
  };

  function callPhoneNumber() {
    const phoneNumber = `${Platform.OS !== "android" ? "telprompt" : "tel"}:${
      studDetail.PHONE
    }`;

    console.log(phoneNumber);

    Linking.canOpenURL(phoneNumber)
      .then((supported) => {
        if (supported) Linking.openURL(phoneNumber);
      })
      .catch((error) => console.log(error));
  }

  function openAndFormatEmail() {
    const link = `mailto:${studDetail.EMAIL1}`;

    Linking.canOpenURL(link)
      .then((supported) => {
        if (supported) Linking.openURL(link);
      })
      .catch((err) => console.log(error));
  }

  const addContact = async () => {
    const contact = {
      [Contacts.Fields.FirstName]: studDetail.DISNAME || "Unknown",
      [Contacts.Fields.PhoneNumbers]: studDetail.PHONE
        ? [{ label: "mobile", number: studDetail.PHONE }]
        : [],
      [Contacts.Fields.Emails]: studDetail.EMAIL1
        ? [{ label: "work", email: studDetail.EMAIL1 }]
        : [],
    };

    try {
      const contactId = await Contacts.addContactAsync(contact);
      if (contactId) {
        Alert.alert("Success", "Contact added successfully!");
      } else {
        Alert.alert("Failed", "Failed to add contact.");
      }
    } catch (error) {
      console.error("Error adding contact:", error);
      Alert.alert("Error", "An error occurred while adding the contact.");
    }
  };

  return (
    <Layout style={styles.container}>
      <SafeAreaView style={styles.safeArea}>
        <ScrollView>
          <View style={styles.headerContainer}>
            <Avatar
              source={image ? { uri: image } : { uri: uric }}
              style={styles.profileAvatar}
            />
            {studDetail && studDetail.isgrounded === "1" && (
              <Text style={styles.groundedText}>
                {studDetail.DISNAME} is GROUNDED
              </Text>
            )}

            <Text category="h1" style={styles.profileName}>
              {studDetail ? studDetail.DISNAME : ""}
            </Text>
            <ButtonGroup
              style={styles.buttonGroup}
              appearance="outline"
              size="small"
            >
              <Button
                onPress={addContact}
                status="success"
                accessoryLeft={(props) => (
                  <Icon {...props} name="person-add-outline" />
                )}
                style={styles.button}
              >
                Add to Contacts
              </Button>
              <Button
                onPress={() =>
                  navigation.navigate("StudentMap", { course: studDetail })
                }
                accessoryLeft={(props) => (
                  <Icon {...props} name="map-outline" />
                )}
                style={styles.button}
              >
                Course Map
              </Button>
              <Button
                onPress={() =>
                  navigation.navigate("StudentCourse", { course: studDetail })
                }
                accessoryLeft={(props) => (
                  <Icon {...props} name="book-outline" />
                )}
                style={styles.button}
              >
                Course
              </Button>
            </ButtonGroup>
          </View>

          <View style={styles.sectionContainer}>
            <Text category="h5" style={styles.sectionHeader}>
              Student Information
            </Text>
          </View>

          <Card style={styles.card}>
            <Text category="p1" style={styles.cardText}>
              Course: {studDetail.COURSE}
            </Text>
            <Text category="p1" style={styles.cardText}>
              Flight Block: {studDetail.FLT_BLK}
            </Text>
            <Text category="p1" style={styles.cardText}>
              Team: {studDetail.TEAM}
            </Text>
            <Text category="p1" style={styles.cardText}>
              Instructor: {studDetail.INST}
            </Text>
          </Card>

          <Card style={styles.card}>
            <Button onPress={openAndFormatEmail}>
              <Text category="s1" style={styles.cardText}>
                Email: {studDetail.EMAIL1}
              </Text>
            </Button>
          </Card>

          <Card style={styles.card}>
            <Button onPress={callPhoneNumber}>
              <Text category="s1" style={styles.cardText}>
                Phone: {studDetail.PHONE}
              </Text>
            </Button>
          </Card>
          <View style={styles.sectionContainer}>
            <Text category="h5" style={styles.sectionHeader}>
              Additional Information
            </Text>
          </View>

          <Card style={styles.card}>
            <Text category="p1" style={styles.cardText}>
              Registration ID: {studDetail.ID}
            </Text>
            <Text category="p1" style={styles.cardText}>
              Last Flown: {studDetail.LAST_FLY}
            </Text>
            <Text category="p1" style={styles.cardText}>
              Training Calendar: {studDetail.TRAINCAL}
            </Text>
            <Text category="p1" style={styles.cardText}>
              Next Checkride: {studDetail.NEXT_CHK}
            </Text>
          </Card>

          <View style={styles.sectionContainer}>
            <Text category="h5" style={styles.sectionHeader}>
              Unit Performance
            </Text>
          </View>

          <Card style={styles.card}>
            <Text category="p1" style={styles.cardText}>
              Completed Units: {studDetail.completed}
            </Text>
            <Text category="p1" style={styles.cardText}>
              Attempted Units: {studDetail.attempt}
            </Text>
            <Text category="p1" style={styles.cardText}>
              Incomplete Units: {studDetail.incomplete}
            </Text>
            <Text category="p1" style={styles.cardText}>
              Remaining Units: {studDetail.remaining}
            </Text>
            <Text category="p1" style={styles.cardText}>
              Failed Units: {studDetail.failures}
            </Text>
          </Card>
        </ScrollView>
      </SafeAreaView>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F7F9FC",
  },
  safeArea: {
    flex: 1,
  },
  headerContainer: {
    alignItems: "center",
    padding: 20,
    backgroundColor: "#ffffff",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 4,
    marginBottom: 20,
    borderRadius: 15, // More rounded header container
  },
  profileAvatar: {
    width: 120, // Slightly larger profile image
    height: 120,
    borderRadius: 60, // Make the image circular
    marginBottom: 16,
    borderWidth: 2,
    borderColor: "#3366FF", // Add a border for a cleaner look
  },
  profileName: {
    fontSize: 26, // Larger font size for profile name
    fontWeight: "700", // Bold weight for prominence
    marginTop: 10,
    color: "#2E3A59", // Darker text color for readability
  },
  buttonGroup: {
    flexDirection: "row",
    justifyContent: "space-between", // Better spacing between buttons
    alignItems: "center",
    flexWrap: "wrap",
    width: "100%",
    paddingHorizontal: 16,
    paddingVertical: 10,
    marginTop: 16,
  },
  button: {
    flex: 1,
    marginHorizontal: 10, // More spacing between buttons
    marginVertical: 10,
    borderRadius: 8, // Subtle rounded corners
    borderColor: "transparent", // Remove border
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 5,
    elevation: 3, // Soft shadow for depth
    minWidth: "30%",
  },
  sectionContainer: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: "#E5E9F2",
    borderRadius: 10,
    marginVertical: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2, // Adds depth to the section container
  },
  sectionHeader: {
    fontWeight: "700", // Make the header bold
    color: "#2E3A59",
    fontSize: 22, // Larger header text
    marginBottom: 8, // More space below header
  },
  card: {
    marginHorizontal: 16,
    marginVertical: 12,
    borderRadius: 12, // More rounded corners
    backgroundColor: "#ffffff", // White card background
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 5,
    elevation: 3, // Soft shadow to make cards more prominent
    paddingVertical: 14,
    paddingHorizontal: 18,
  },
  cardText: {
    color: "#2E3A59",
    fontSize: 18, // Slightly larger font size for better readability
  },
  groundedText: {
    color: "#ff3d71", // Use a red-pink for emphasis
    fontSize: 28,
    fontWeight: "bold",
    marginTop: 10,
    marginBottom: 10,
  },
});
export default StudentDetailScreen;
