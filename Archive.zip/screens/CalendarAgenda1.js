import React from 'react';
import {
  SafeAreaView,
  ScrollView,
  View,
  StyleSheet,
  Text,
  TouchableOpacity,
  Dimensions
} from 'react-native';
import { Agenda } from 'react-native-calendars';

//function App() {
const AgendaScreen = () => {
  const w = Dimensions.get('window');
  console.log('w',w);
  return (
    <View style={styles.container} width={w.width}>
      <Agenda 
        selected="2023-10-12"
        items={{
          '2023-10-12': [{name: 'Coding'}, {name: 'Workout'}, {name: 'Dinner'}],
          '2023-10-13': [{name: 'Writing'}]
        }}
        renderItem={(item, isFirst) => (
          <TouchableOpacity style={styles.item}>
            <Text style={styles.itemText}>{item.name}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#0a8faf',
  },
  item: {
    backgroundColor: 'white',
    flex: 1,
    borderRadius: 105,
    padding: 10,
    marginRight: 10,
    marginTop: 17,
  },
  itemText: {
    color: '#888',
    fontSize: 5,
  }
});

export default AgendaScreen;