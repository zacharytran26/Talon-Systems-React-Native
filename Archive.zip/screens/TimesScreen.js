import React from "react";
import { StyleSheet, SafeAreaView, View } from "react-native";
import { Layout, Text, Card } from "@ui-kitten/components";
import { useRoute } from "@react-navigation/native";
import { FlashList } from "@shopify/flash-list";

const Times = () => {
  const route = useRoute();
  const { times } = route.params;

  const renderTimeItem = ({ item }) => (
    <View style={styles.timeItemContainer}>
      <Card style={styles.card}>
        <Text style={styles.cardTitle}>Event Start</Text>
        <Text style={styles.cardContent}>{item.eventStart}</Text>

        <Text style={styles.cardTitle}>Brief Duration</Text>
        <Text style={styles.cardContent}>{item.briefDur}</Text>

        <Text style={styles.cardTitle}>Activity Start</Text>
        <Text style={styles.cardContent}>{item.actStart}</Text>

        <Text style={styles.cardTitle}>Duration</Text>
        <Text style={styles.cardContent}>{item.actDur}</Text>

        <Text style={styles.cardTitle}>Activity Stop</Text>
        <Text style={styles.cardContent}>{item.actStop}</Text>

        <Text style={styles.cardTitle}>Debrief Duration</Text>
        <Text style={styles.cardContent}>{item.debriefDur}</Text>

        <Text style={styles.cardTitle}>Event Stop</Text>
        <Text style={styles.cardContent}>{item.eventStop}</Text>
      </Card>
    </View>
  );

  return (
    <Layout style={styles.container}>
      <SafeAreaView style={{ flex: 1 }}>
        <View style={styles.header}>
          <Text style={styles.title}>Event Times</Text>
        </View>
        <FlashList
          data={[times]}
          renderItem={renderTimeItem}
          keyExtractor={(item, index) => index.toString()}
          contentContainerStyle={styles.list}
          estimatedItemSize={200}
        />
      </SafeAreaView>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: "#F7F9FC",
  },
  header: {
    marginBottom: 16,
    alignItems: "center",
  },
  title: {
    fontWeight: "bold",
    fontSize: 24, // Increased for emphasis
    color: "#2E3A59",
    letterSpacing: 0.8, // Slight spacing for readability
  },
  list: {
    paddingBottom: 16,
  },
  timeItemContainer: {
    marginBottom: 16,
  },
  card: {
    padding: 16,
    backgroundColor: "#FFFFFF",
    borderRadius: 12, // Softer corners
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 }, // More subtle shadow
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  cardTitle: {
    fontWeight: "700", // Heavier font for emphasis
    fontSize: 16,
    color: "#4A5568", // Slightly darker for titles
    marginBottom: 2, // Tighter spacing
  },
  cardContent: {
    fontSize: 15,
    color: "#2E3A59",
    marginBottom: 8, // Even spacing between lines
    paddingLeft: 10, // Indent for content
  },
});

export default Times;
