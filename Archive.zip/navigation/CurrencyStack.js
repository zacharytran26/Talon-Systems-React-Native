// import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import CurrencyScreen from "../screens/CurrScreens/Currencies";
import InstructorsScreen from "../screens/CurrScreens/InstructorScreen";
import StudentsScreen from "../screens/CurrScreens/StudentScreen";
import InstructorList from "../screens/CurrScreens/InstructorDetailScreen";
import StudentList from "../screens/CurrScreens/StudentDetailScreen";
import LogoutScreen from "../screens/CurrScreens/Logout";
import StudentCourse from "../screens/CurrScreens/StudentCourseScreen";
import StudentMap from "../screens/CurrScreens/StudentMap";
import StudentMapDetails from "../screens/CurrScreens/StudentMapsDetail";
import LineItem from "../screens/CurrScreens/LineItems";
import Approve from "../screens/CurrScreens/ApprovalScreen";
import Times from "../screens/CurrScreens/TimesScreen";
import DisplayImage from "../screens/CurrScreens/ImageScreen";
import Activity from "../screens/CurrScreens/ActivityScreen";
import InstructorActivity from "../screens/CurrScreens/InstructorActivity";
import ApproveActivity from "../screens/CurrScreens/ActivityApproval";
import ConfirmFIF from "../screens/CurrScreens/ConfirmationFIF";
import SettingsScreen from "../screens/CurrScreens/SettingScreen";
import PendingAuths from "../screens/CurrScreens/PendingAuths";
import FIFScreen from "../screens/CurrScreens/FIFScreen";
import LogScreen from "../screens/CurrScreens/LogScreen";

const Stack = createNativeStackNavigator();

export default function CurrencyStackNavigator() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
        headerBackTitleVisible: false,
      }}
    >
      <Stack.Screen name="Currency" component={CurrencyScreen} />
      <Stack.Screen
        name="CInstructorScreen"
        component={InstructorsScreen}
        initialParams={{ context: "Currency" }} // Pass context-specific params
      />
      <Stack.Screen name="CStudentScreen" component={StudentsScreen} />
      <Stack.Screen name="CInstructorDetailScreen" component={InstructorList} />
      <Stack.Screen name="CStudentDetailScreen" component={StudentList} />
      <Stack.Screen name="CLogout" component={LogoutScreen} />
      <Stack.Screen name="CStudentCourse" component={StudentCourse} />
      <Stack.Screen name="CStudentMap" component={StudentMap} />
      <Stack.Screen name="CStudentMapDetails" component={StudentMapDetails} />
      <Stack.Screen name="CLineItem" component={LineItem} />
      <Stack.Screen name="CAuth" component={Approve} />
      <Stack.Screen name="CTimes" component={Times} />
      <Stack.Screen name="CImage" component={DisplayImage} />
      <Stack.Screen name="CActivity" component={Activity} />
      <Stack.Screen name="CActivityApproval" component={ApproveActivity} />
      <Stack.Screen name="CConfirm" component={ConfirmFIF} />
      <Stack.Screen name="CInstructorActivity" component={InstructorActivity} />
      <Stack.Screen name="CLog" component={LogScreen} />
      <Stack.Screen name="CSettings" component={SettingsScreen} />
      <Stack.Screen name="CPendingAuth" component={PendingAuths} />
      <Stack.Screen name="CFIF" component={FIFScreen} />
    </Stack.Navigator>
  );
}
