import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import QualiScreen from "../screens/QualiScreens/QualificationScreen";
import InstructorsScreen from "../screens/QualiScreens/InstructorScreen";
import StudentsScreen from "../screens/QualiScreens/StudentScreen";
import InstructorList from "../screens/QualiScreens/InstructorDetailScreen";
import StudentList from "../screens/QualiScreens/StudentDetailScreen";
import LogoutScreen from "../screens/QualiScreens/Logout";
import StudentCourse from "../screens/QualiScreens/StudentCourseScreen";
import StudentMap from "../screens/QualiScreens/StudentMap";
import StudentMapDetails from "../screens/QualiScreens/StudentMapsDetail";
import LineItem from "../screens/QualiScreens/LineItems";
import Approve from "../screens/QualiScreens/ApprovalScreen";
import Times from "../screens/QualiScreens/TimesScreen";
import DisplayImage from "../screens/QualiScreens/ImageScreen";
import Activity from "../screens/QualiScreens/ActivityScreen";
import InstructorActivity from "../screens/QualiScreens/InstructorActivity";
import ApproveActivity from "../screens/QualiScreens/ActivityApproval";
import ConfirmFIF from "../screens/QualiScreens/ConfirmationFIF";
import SettingsScreen from "../screens/QualiScreens/SettingScreen";
import PendingAuths from "../screens/QualiScreens/PendingAuths";
import FIFScreen from "../screens/QualiScreens/FIFScreen";
import LogScreen from "../screens/QualiScreens/LogScreen";
const Stack = createNativeStackNavigator();

export default function MessagesStackNavigator() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
        headerBackTitleVisible: false,
      }}
    >
      <Stack.Screen name="Quali" component={QualiScreen} />
      <Stack.Screen
        name="QualiInstructorScreen"
        component={InstructorsScreen}
      />
      <Stack.Screen name="QualiStudentScreen" component={StudentsScreen} />
      <Stack.Screen
        name="QualiInstructorDetailScreen"
        component={InstructorList}
      />
      <Stack.Screen name="QualiStudentDetailScreen" component={StudentList} />
      <Stack.Screen name="QualiLogout" component={LogoutScreen} />
      <Stack.Screen name="QualiStudentCourse" component={StudentCourse} />
      <Stack.Screen name="QualiStudentMap" component={StudentMap} />
      <Stack.Screen
        name="QualiStudentMapDetails"
        component={StudentMapDetails}
      />
      <Stack.Screen name="QualiLineItem" component={LineItem} />
      <Stack.Screen name="QualiAuth" component={Approve} />
      <Stack.Screen name="QualiTimes" component={Times} />
      <Stack.Screen name="QualiImage" component={DisplayImage} />
      <Stack.Screen name="QualiActivity" component={Activity} />
      <Stack.Screen name="QualiActivityApproval" component={ApproveActivity} />
      <Stack.Screen name="QualiConfirm" component={ConfirmFIF} />
      <Stack.Screen
        name="QualiInstructorActivity"
        component={InstructorActivity}
      />
      <Stack.Screen name="QualiLog" component={LogScreen} />
      <Stack.Screen name="QualiSettings" component={SettingsScreen} />
      <Stack.Screen name="QualiPendingAuth" component={PendingAuths} />
      <Stack.Screen name="QualiFIF" component={FIFScreen} />
    </Stack.Navigator>
  );
}
